<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About Us</title>
    <?php include_once('../common_links.php'); ?>
    <link rel="stylesheet" href="about_us.css">
</head>

<body class="2xl:container mx-auto">

    <?php
    include('../component/header.php');
    ?>
    <div class="about">
        <div class="about-img"><img src="../resources/img_aboutus.jpg" alt=""></div>
        <div class="about-details">
            <h1>About Us</h1><br><br>
            <p>We are a team of experienced developers who specialize in creating custom e-commerce solutions for
                small businesses. Our focus is on helping local, independent shops to thrive in an increasingly
                competitive retail landscape. We understand the challenges that small businesses face, and we are
                committed to providing tailored solutions that meet their specific needs.
            </p><br>

            <p>In the case of the Cleckhuddersfax suburb, we were approached by a group of small shop owners who
                were concerned about the encroachment of larger chains into their area. We worked closely with them
                to develop a prototype e-commerce platform that allows them to offer their unique products to a
                wider audience. Our system provides a user-friendly interface for customers to browse and purchase
                goods, while also providing the traders with tools to manage their products, view reports on orders
                and stock levels, and track payments. Our team is proud to have been a part of this project, and we
                are committed to continuing to support small businesses like these in their growth and success.
            </p><br>
            <p><i class="bi bi-telephone"></i> <a href="tel:+977 9823123458">+977 9823123458</a></p><br>
            <p><i class="bi bi-envelope"></i> <a
                    href="mailto:freemanurbanstore@gmail.com">freemanurbanstore@gmail.com</a></p>
        </div>
    </div>
    <h2 class="testimonials-title ">Testimonials</h2>
    <div class="testimonials mt-[32px]">
        <div class="testimonial-card">
            <img src="../resources/img_testimonial.jpg" alt="">
            <p class="name">Patrick Bamford</p>
            <span class="ratings"><i class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i><i
                    class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i></span>
            <p class="text">I've tried several ecommerce platforms, but this one is the best. The product
                descriptions are accurate, the prices are unbeatable, and the quality is impressive. Shipping is
                fast and the customer service is excellent. I appreciate the hassle-free return policy too. Shopping
                here is always a pleasure and I recommend it to anyone looking for a reliable and convenient
                shopping experience..</p>
        </div>
        <div class="testimonial-card">
            <img src="../resources/img_testimonial2.jpg" alt="">
            <p class="name">Jack Harrison</p>
            <span class="ratings"><i class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i><i
                    class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i></span>
            <p class="text">I've tried several ecommerce platforms in the past, but this one stands out. The product
                descriptions are accurate and the quality of the products is impressive. I'm always satisfied with
                my purchases and I recommend this platform to anyone looking for a great shopping experience.</p>
        </div>
        <div class="testimonial-card">
            <img src="../resources/img_testimonial3.jpg" alt="">
            <p class="name">Sam Greenwood</p>
            <span class="ratings"><i class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i><i
                    class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i></span>
            <p class="text">Shopping on this ecommerce platform is a game-changer. The site is easy to navigate,
                with an extensive selection of products and competitive prices. The personalized recommendations and
                rewards program make shopping even more enjoyable. The customer service is fantastic - they're
                always available to answer any questions I have. I highly recommend this platform to anyone looking
                for a great shopping experience.</p>
        </div>
    </div>

    <?php include('../component/footer.php'); ?>

</body>
<script src="../component/header.js"></script>
<script src="../js_utils.js"></script>

</html>