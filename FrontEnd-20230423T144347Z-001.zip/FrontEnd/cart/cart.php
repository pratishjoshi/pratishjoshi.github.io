<?php
namespace model;

include('../all_models.php');

$SERVER_REFERER = "Location: {$_SERVER['HTTP_REFERER']}";
$action = "none";
if (isset($_GET['action'])) {
    $action = $_GET['action'];
}

if ($action == "add") {
    if (isset($_GET['id'])) {
        $id = $_GET['id'];
        $user = getUserDetails();
        if ($user != null) {
        } else {
            $cartItems = array();
            if (getCookieValue(Constants::CACHE_GUEST_CART) != null) {
                $cartItems = json_decode(getCookieValue(Constants::CACHE_GUEST_CART));
            }
            array_unshift($cartItems, $id);
            setcookie(Constants::CACHE_GUEST_CART, json_encode($cartItems), 86400 * 28, "/");
        }
    }
}

if ($action == "remove") {
    if (isset($_GET['id'])) {
        $id = $_GET['id'];
        $user = getUserDetails();
        if ($user != null) {

        } else {
            $cartItems = array();
            if (getCookieValue(Constants::CACHE_GUEST_CART) != null) {
                $cartItems = json_decode(getCookieValue(Constants::CACHE_GUEST_CART));
            }
            array_shift($cartItems);
            setcookie(Constants::CACHE_GUEST_CART, json_encode($cartItems), 86400 * 28, "/");
        }
    }

    header($SERVER_REFERER);
}

?>