<?php
namespace model;

include('../all_models.php');

$user = getUserDetails();
if ($user != null and $user->role != "customer") {
    header("Location:../index.php");
}

if ($user == null) {
    $cartProducts = array();
    if (getCookieValue(Constants::CACHE_GUEST_CART) != null) {
        $cartProducts = json_decode(getCookieValue(Constants::CACHE_GUEST_CART));
    }
    $query = "SELECT PRODUCT_ID, NAME, DESCRIPTION, PRICE, IMAGE FROM PRODUCT WHERE 1!=1 ";
    foreach ($cartProducts as $item) {
        $query = "OR PRODUCT_ID = " . $item . " ";
    }
} else {
    $query = "SELECT p.PRODUCT_ID, p.NAME, p.IMAGE, p.DESCRIPTION, p.PRICE, p.QUANTITY
    FROM CART c
    JOIN CART_ITEM ci ON c.CART_ID = ci.CART_ID
    JOIN PRODUCT p ON ci.PRODUCT_ID = p.PRODUCT_ID
    WHERE c.USER_ID = $user->id;";
}
$cartItem = Dao::executeQueryForResult($query);

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php include('../common_links.php'); ?>
    <title>Cart</title>
</head>

<body class="2xl:container mx-auto px-[16px]">

    <?php include('../component/header.php'); ?>

    <div class="lexend-medium text-[36px] mt-[32px]">Cart</div>
    <div class="flex flex-column overflow-auto gap-[32px] mt-[16px]">
        <?php
        horizontal_product_card_cart();
        horizontal_product_card_cart();
        horizontal_product_card_cart();
        horizontal_product_card_cart();
        ?>
    </div>
    <div class="lexend-medium text-[36px] mt-[32px]">Order Summary</div>
    <?php

    // Perform these on top
    $titles = array("Id" => "id", "Name" => "name", "Quantity" => "quantity", "Price" => "price", "Total Price" => "total_price");
    $values = array();

    cart_table($titles, $values);
    ?>

    <form method="POST" action="">
        <div class="flex flex-row flex-wrap justify-between mt-[-24px] mb-[-24px]">

            <div class="inputBx w-[100%] lg:w-[45%]">
                <span class="lexend-medium text-[36px] mt-[32px]">Collection Slot</span>
                <select name="categoryFilter">
                    <option value="" disabled selected>Collection Time</option>
                    <option value="wed">Wednesday 10am - 1pm</option>
                    <option value="thur">Thursday 1pm - 4pm</option>
                    <option value="fri">Friday 4pm - 7pm</option>
                </select>
            </div>

            <div class="inputBx mt-auto w-[100%] lg:w-[45%]">
                <input type="submit" value="CHECKOUT" name="btnSendMessageCart">
            </div>
        </div>
        </div>
    </form>
</body>
<script src="../component/header.js"></script>
<script src="../js_utils.js"></script>

</html>