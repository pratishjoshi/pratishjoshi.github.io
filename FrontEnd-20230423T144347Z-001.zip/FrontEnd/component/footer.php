<div class="footer mt-[32px] ">
    <div class="left">
        <div> <a href="../"> <img width="80%" src="../resources/LogoLight.svg" alt="Site logo"> </a> </div>
        <p class="text-[#ffffff] mt-[8px] font-light">We are a group of independent farmers who have come together to
            explore the possibility of offering an online platform to sell our fresh produce. We want to make it easier
            for customers to buy our products while maintaining our work-life balance.</p>
        <br>
        <div class="justify-center text-[#ffffff]">"Shop with ease, anytime, anywhere!"</div>
        <div class="flex align-center gap-[8px] mt-[16px]">
            <i class="bi bi-briefcase text-[#ffffff]"></i>
            <a href="../trader_registration/trader_registration_page.php"><p> Become Trader </p></a>
        </div>
    </div>
    <div class="right p-[16px] md:px-[32px] p-[16px]">
        <div class="right-top gap-[16px] justify-between sm:gap-[32px]">
            <div>
                <ul>
                    <h5 class="mb-[16px] md:mb-[32px] lexend-regular text-[24px]"> Navigation </h5>
                    <li> <a href="../cart/cart_page.php" class="font-normal text-[18px]"> Cart </a></li>
                    <li> <a href="../component/homepage.php" class="font-normal text-[18px]"> Homepage </a></li>
                    <li> <a href="../favourties/favourites_page.php" class="font-normal text-[18px]"> Favourites </a></li>
                    <?php
                    use model\Constants;

                    if (getLoggedInType() != null) {
                        echo '<li> <a href="#" onclick="logOutClick()" class="font-normal text-[18px]"> Logout </a></li>';
                    } else {
                        echo '<li> <a href="../customer_registration/customer_registration_page.php" class="font-normal text-[18px]"> Sign Up </a></li>';
                    }
                    ?>
                </ul>
            </div>
            <div>
                <ul>
                    <h5 class="mb-[16px] md:mb-[32px] lexend-regular text-[24px]"> Help </h5>
                    <li> <a href="../contact_us/contact_us_page.php" class="font-normal text-[18px]"> Feedback </a></li>
                    <li> <a href="../about_us/about_us.php" class="font-normal text-[18px]"> About Us </a></li>
                    <li> <a href="../contact_us/contact_us_page.php" class="font-normal text-[18px]"> Contact Us </a>
                    </li>
                    <li> <a href="#" class="font-normal text-[18px]"> Help Center </a></li>
                </ul>
            </div>
            <div class="contact">
                <ul>
                    <h5 class="mb-[16px] md:mb-[32px] lexend-regular text-[24px]"> Contact </h5>
                    <li> <i class="bi bi-telephone text-[18px]"></i> &nbsp; <span> <a href="tel:+977 9823123456 "
                                class="font-normal text-[18px]"> +977 9823123456
                            </a></span><br> </li>
                    <li> <i class="bi bi-envelope text-[18px]"></i> &nbsp; <span> <a
                                href="mailto:freemanurbanstore@gmail.com" class="font-normal text-[18px]">
                                freemanurbanstore@gmail.com </a> </span></li>
                </ul>
            </div>
        </div>
        <div class="right-last justify-center md:justify-between mt-[8px] flex-wrap">
            <div class="right-last-left flex-wrap">
                <p> <a href="#"> Terms of Use </a></p>
                <p> <a href="#"> Privacy Policy </a> </p>
            </div>
            <p> All Right reserved by Freeman Urban Store | 2023 </p>
        </div>
    </div>
</div>