let catSeg = true;
const downarr = document.querySelector('.fa-angle-down');
const category = document.querySelector("#category");
const subMenu = document.querySelector(".sub-menu");
const menuBtn = document.querySelector(".menu-icon span");
const searchBtn = document.querySelector(".search-icon");
const cancelBtn = document.querySelector(".cancel-icon");
const items = document.querySelector(".items");
const form = document.querySelector(".search-icons");
const last = document.querySelector(".last-items");
const btnSearchBar = document.querySelector(".btnSearchBar");
const searchBar = document.querySelector(".searchBar");

menuBtn.onclick = () => {
    items.classList.add("active");
    last.classList.add("active");
    menuBtn.classList.add("hide");
    searchBtn.classList.add("hide");
    cancelBtn.classList.add("show");
}
cancelBtn.onclick = () => {
    last.classList.remove("active");
    items.classList.remove("active");
    menuBtn.classList.remove("hide");
    searchBtn.classList.remove("hide");
    cancelBtn.classList.remove("show");
    form.classList.remove("active");
    cancelBtn.style.color = "#ff3d00";
}
searchBtn.onclick = () => {
    form.classList.add("active");
    searchBtn.classList.add("hide");
    cancelBtn.classList.add("show");
}

btnSearchBar.addEventListener('click', () => {
    const searchTitle = searchBar.value;
    const xhr = new XMLHttpRequest();
    xhr.open('GET', `/product/product_page.php?searchTitle=${searchTitle}`, true);
    xhr.onload = () => {
      if (xhr.status === 200) {
        window.location.href = '/product/product_page.php?searchTitle=' + searchTitle;
      } else {
        alert(xhr.statusText);
      }
    };
    xhr.send();
  });


category.addEventListener('click', () => {
    console.log(catSeg);
    if (catSeg) {
        downarr.classList.add('fa-rotate-180');
        subMenu.style.display = "block";
        catSeg = false;
    }
    else {
        downarr.classList.remove('fa-rotate-180');
        subMenu.style.display = "none";
        catSeg = true;
    }
})