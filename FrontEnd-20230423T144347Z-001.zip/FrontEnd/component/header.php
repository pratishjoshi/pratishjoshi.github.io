<?php
namespace model;

include('../all_models.php');
?>

<nav>
    <ul class="justify-around">
        <div class="menu-icon"><span class="fas fa-bars"></span></div>
        <li class="logo cursor-pointer"><img src="../resources/LogoDark.svg" alt="Logo" onclick="redirectToIndex()">
        </li>
        <div class="items">
            <li>
                <a href="#" class="main-anchor" id="category">Categories <i class="fa-solid fa-angle-down"></i></a>
                <div class="sub-menu">
                    <ul>
                        <li><a href="../product/product_page.php?searchTitle=Bakery">Bakery</a></li>
                        <li><a href="../product/product_page.php?searchTitle=Butcher">Butcher</a></li>
                        <li><a href="../product/product_page.php?searchTitle=Fishmonger">Fishmonger</a></li>
                        <li><a href="../product/product_page.php?searchTitle=Greengrocer">Greengrocer</a></li>
                        <li><a href="../product/product_page.php?searchTitle=Delicatessen">Delicatessen</a></li>
                    </ul>
                </div>
            </li>
            <li><a href="#" onclick="redirectToAboutUs()" class="main-anchor">About Us</a></li>
            <li><a href="#" onclick="redirectToContactUs()" class="main-anchor">Contact Us</a></li>
        </div>
        <div class="search-icon"><span class="fas fa-search"></span></div>
        <div class="cancel-icon"><span class="fas fa-times"></span></div>
        <li class="search-icons">
            <input placeholder="Search Products" class="searchBar">
            <span class="fas fa-search btnSearchBar"></span>
        </li>
        <div class="items last-items">
            <span>
                <img src="../resources/ic_user.svg" alt="">
                <?php
                if (isset($_COOKIE[Constants::LOGGED_IN_USER])) {
                    echo '<a href="../profile/profile_page.php">Account</a>';
                } else {
                    echo '<a href="../login/login_page.php">Login</a>';
                }
                ?>
            </span>
            <span>
                <img src="../resources/ic_cart_filled.svg" alt="">
                <a href="../cart/cart_page.php">Cart</a>
            </span>
        </div>
    </ul>
</nav>