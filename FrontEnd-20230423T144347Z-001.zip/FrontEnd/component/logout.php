<?php
namespace model;
include('../all_models.php');

    removeCookie(Constants::LOGGED_IN_USER);
    header("Location:../index.php");
?>