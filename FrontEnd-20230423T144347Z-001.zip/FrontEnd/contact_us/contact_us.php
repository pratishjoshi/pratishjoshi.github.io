<?php

namespace model;

require('../all_models.php');

if (isset($_POST['btnSendMessageCu'])) {
    $SERVER_REFERER = "Location: {$_SERVER['HTTP_REFERER']}";
    $firstname = secure($_POST['firstnameCu']);
    $lastname = secure($_POST['lastnameCu']);
    $email = secure($_POST['emailCu']);
    $message = secure($_POST['messageCu']);

    if (isContactDetailsValid($firstname, $lastname, $email, $message)) {
        $fullname = $firstname . " " . $lastname;
        Mailer::sendContactUsMessage($fullname, $email, $message);
    }

    header($SERVER_REFERER);
}
function isContactDetailsValid($firstname, $lastname, $email, $message): bool
{
    $isvalidfirstname = true;
    $isvalidlastname = true;

    if (empty($firstname)) {
        setsession(Constants::FIRST_NAME_ERROR, "Please enter your firstname");
        $isvalidfirstname = false;
    }
    if (empty($lastname)) {
        setsession(Constants::LAST_NAME_ERROR, "Please enter your lastname");
        $isvalidfirstname = false;
    }
    $isvalidemail = isValidEmail($email);
    $isvalidmessage = true;
    if (empty($message)) {
        setsession(Constants::DESCRIPTION_ERROR, "Please enter a message");
        $isvalidmessage = false;
    }
    $isValid = $isvalidfirstname && $isvalidlastname && $isvalidemail && $isvalidmessage;
    if (!$isValid) {
        setsession(Constants::CACHE_FIRST_NAME, $firstname);
        setsession(Constants::CACHE_LAST_NAME, $lastname);
        setsession(Constants::CACHE_EMAIL, $email);
        setsession(Constants::CACHE_DESCRIPTION, $message);
    }
    return $isValid;
}