<?php
namespace model;

include('../all_models.php');
$user = getUserDetails();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php include('../common_links.php'); ?>
    <title>Add Product</title>
</head>

<body class="2xl:container mx-auto justify-center">
    <?php include('../component/header.php'); ?>

    <div class="flex flex-row flex-wrap items-center justify-center mt-[32px] min-h-[1024px] max-h-[1024px]">

        <div class="basis-1/2 hidden lg:block">

            <img class="object-cover rounded-[16px] h-[1024px]" src="../resources/img_customer_register.jpg"
                alt="Display Image">

        </div>

        <!-- remove form-content and replace with the below line of code -->
        <div class="basis-[100%] lg:basis-1/2 max-h-[1024px] overflow-y-auto">

            <!-- remove form and replace with the below line of code -->
            <div class="w-[100%] px-[32px] lg:px-[64px]">

                <!-- Everything else is same just copy your content inside of form and paste here -->
                <div class="form-intro">
                    Add Product
                </div>
                <?php
                echo showSuccess(printSessionValue(Constants::STATUS_SUCCESS));
                echo showAlert(printSessionValue(Constants::STATUS_ERROR));
                ?>
                <form action="add_product.php" method="POST" enctype="multipart/form-data">

                    <div class="inputBx">
                        <span>Product Name</span>
                        <input type="text" name="productNameApp"
                            value=" <?php printSessionValue(Constants::CACHE_PRODUCT_NAME) ?>">
                        <div class="inputMessage">
                            <?php printSessionValue(Constants::PRODUCT_NAME_ERROR) ?>
                        </div>
                    </div>

                    <div class="flex flex-row justify-between mt-[-24px] mb-[-24px]">
                        <div class="w-[45%] inputBx">
                            <span>Product Price</span>
                            <input type="number" name="productPriceApp"
                                value="<?php printSessionValue(Constants::CACHE_PRODUCT_PRICE) ?>">
                            <div class="inputMessage">
                                <?php printSessionValue(Constants::PRODUCT_PRICE_ERROR) ?>
                            </div>
                        </div>
                        <div class="w-[45%] inputBx">
                            <span>Product Quantity</span>
                            <input type="number" name="productQuantityApp"
                                value="<?php printSessionValue(Constants::CACHE_PRODUCT_QUANTITY) ?>">
                            <div class="inputMessage">
                                <?php printSessionValue(Constants::PRODUCT_QUANTITY_ERROR) ?>
                            </div>
                        </div>
                    </div>

                    <div class="flex flex-row justify-between mt-[-24px] mb-[-24px]">
                        <div class="w-[45%] inputBx">
                            <span>Minimum Order</span>
                            <input type="number" name="minimumOrderApp"
                                value="<?php printSessionValue(Constants::CACHE_MINIMUM_ORDER) ?>">
                            <div class="inputMessage">
                                <?php printSessionValue(Constants::MINIMUM_ORDER_ERROR) ?>
                            </div>
                        </div>
                        <div class="w-[45%] inputBx">
                            <span>Maximum Order</span>
                            <input type="number" name="maximumOrderApp"
                                value="<?php printSessionValue(Constants::CACHE_MAXIMUM_ORDER) ?>">
                            <div class="inputMessage">
                                <?php printSessionValue(Constants::MAXIMUM_ORDER_ERROR) ?>
                            </div>
                        </div>
                    </div>

                    <div class="inputBx">
                        <span>Product Category</span>
                        <p class="text-sm text-[#808080]">Please enter Alt(Option) + Enter to add a category.</p>
                        <input type="text" name="productCategoryApp"
                            value="<?php printSessionValue(Constants::CACHE_PRODUCT_CATEGORY) ?>">
                        <div class="inputMessage">
                            <?php printSessionValue(Constants::PRODUCT_CATEGORY_ERROR) ?>
                        </div>
                    </div>

                    <div class="flex flex-col">
                        <span class="rubik-regular mb-[16px]">Product Image</span>
                        <div class="bg-[#f5f7f6] h-[56px] items-center flex rounded-[8px]">
                            <input type="file" name="imageApp" id="file-input"
                                class="rubik-regular block w-full items-center rounded-md text-sm file:bg-transparent file:border-0 file:bg-gray-100 file:mr-4 file:py-3 file:px-4">
                        </div>
                        <div class="inputMessage">
                            <?php printSessionValue(Constants::PRODUCT_IMAGE_ERROR) ?>
                        </div>
                    </div>

                    <div class="inputBx">
                        <span>Shop Name</span>
                        <select name="shopIdApp">
                            <option value="" selected>Shop Name</option>
                            <?php
                            $getShopsQuery = "SELECT SHOP_ID, NAME FROM SHOP WHERE USER_ID = $user->id;";
                            $shops = Dao::executeQueryForResult($getShopsQuery);
                            if ($shops) {
                                foreach ($shops as $shop) {
                                    echo '<option value="' . $shop['SHOP_ID'] . '">' . $shop['NAME'] . '</option>';
                                }
                            }
                            ?>
                        </select>
                        <div class="inputMessage">
                            <?php printSessionValue(Constants::SHOP_NAME_ERROR) ?>
                        </div>
                    </div>

                    <div class="inputBx">
                        <span>Description</span>
                        <input type="message" name="descriptionApp"
                            value="<?php printSessionValue(Constants::CACHE_DESCRIPTION) ?>">
                        <div class="inputMessage">
                            <?php printSessionValue(Constants::DESCRIPTION_ERROR) ?>
                        </div>
                    </div>
                    <div class="inputBx">
                        <input type="submit" value="ADD" name="btnAddApp">
                    </div>
                </form>
            </div>
        </div>
        <?php include('../component/footer.php'); ?>
</body>
<script src="../component/header.js"></script>
<script src="../js_utils.js"></script>

<!-- DO NOT REMOVE THIS CODE BLOCK -->
<script>
    const inputEl = document.querySelector('input[name="productCategoryApp"]');
    const chipsEl = document.createElement('div');
    chipsEl.classList.add('chips');
    inputEl.insertAdjacentElement('afterend', chipsEl);

    inputEl.addEventListener('keydown', (event) => {
        if (event.key === 'Enter' &&  event.code === 'AltLeft') {
            if (inputEl.value !== "") {
                const chipEl = document.createElement('div');
                chipEl.classList.add('chip');
                chipEl.textContent = inputEl.value;
                chipsEl.appendChild(chipEl);
                inputEl.value = '';

                // create a hidden input field with the same name as the original categoriesTr input field
                const hiddenInputEl = document.createElement('input');
                hiddenInputEl.type = 'hidden';
                hiddenInputEl.name = 'categories[]';
                hiddenInputEl.value = chipEl.textContent;
                const submitBtnEl = document.querySelector('input[name="btnAddApp"]');
                submitBtnEl.insertAdjacentElement('beforebegin', hiddenInputEl);
            }

            event.preventDefault(); // prevent form submission
        } else if (event.key === 'Enter') {
            event.preventDefault(); // prevent form submission
            const formEl = document.querySelector('form');
            formEl.submit();
        }
    });
</script>

</html>