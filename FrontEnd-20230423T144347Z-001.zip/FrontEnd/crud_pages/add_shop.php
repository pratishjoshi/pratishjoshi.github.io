<?php
namespace model;

include('../all_models.php');

if (isset($_POST['btnAddAsp'])) {
    $SERVER_REFERER = "Location: {$_SERVER['HTTP_REFERER']}";
    $shopName = secure($_POST['shopNameAsp']);
    $shopEmail = secure($_POST['emailAsp']);
    $phone = secure($_POST['phoneAsp']);
    $description = secure($_POST['descriptionAsp']);

    if (isDetailsValid($shopName, $shopEmail, $phone, $description)) {
        
    }
    header($SERVER_REFERER);

}

function isDetailsValid($name, $email, $phone, $description)
{
    $isNameValid = validateEmpty($name, Constants::SHOP_NAME_ERROR, "Please enter your shop name");
    $isEmailValid = empty($email);
    if (!$isEmailValid) {
        $isEmailValid = isValidEmail($email);
    }
    $isPhoneValid = empty($phone);
    if (!$isPhoneValid) {
        $isPhoneValid = isValidPhone($phone);
    }
    $isDescriptionValid = validateEmpty($description, Constants::DESCRIPTION_ERROR, "Please enter your shop description");

    return $isNameValid and $isDescriptionValid;
}

?>