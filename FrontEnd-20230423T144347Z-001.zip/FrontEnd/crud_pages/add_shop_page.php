<?php
namespace model;

include('../all_models.php');
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php include_once('../common_links.php'); ?>
    <title>Add Shop</title>
</head>

<body class="2xl:container mx-auto justify-center">

    <?php include('../component/header.php'); ?>

    <div class="flex flex-row flex-wrap items-center justify-center mt-[32px] min-h-[1024px] max-h-[1024px]">

        <div class="basis-1/2 hidden lg:block">

            <!-- Put image here --> 
            <img class="object-cover rounded-[16px] h-[1024px]" src="../resources/img_customer_register.jpg" alt="Display Image">

        </div>

        <!-- remove form-content and replace with the below line of code -->
        <div class="basis-[100%] lg:basis-1/2 max-h-[1024px] overflow-y-auto">

            <!-- remove form and replace with the below line of code -->
            <div class="w-[100%] px-[32px] lg:px-[64px]">

                <!-- Everything else is same just copy your content inside of form and paste here -->
                <div class="form-intro">
                    Add Shop
                </div>
                <?php
                echo showAlert(printSessionValue(Constants::STATUS_ERROR));
                ?>
                <form action="add_shop.php" method="POST">

                    <div class="inputBx">
                        <span>Shop Name</span>
                        <input type="text" name="shopNameAsp"
                            value="<?php printSessionValue(Constants::CACHE_SHOP_NAME) ?>">
                        <div class="inputMessage">
                            <?php printSessionValue(Constants::SHOP_NAME_ERROR) ?>
                        </div>
                    </div>

                    <div class="inputBx">
                        <span>Email</span>
                        <input type="email" placeholder="Optional" name="emailAsp"
                            value="<?php printSessionValue(Constants::CACHE_EMAIL) ?>">
                        <div class="inputMessage">
                            <?php printSessionValue(Constants::EMAIL_ERROR) ?>
                        </div>
                    </div>

                    <div class="inputBx">
                        <span>Phone Number</span>
                        <input type="number" placeholder="Optional" name="phoneAsp"
                            value="<?php printSessionValue(Constants::CACHE_PHONE) ?>">
                        <div class="inputMessage">
                            <?php printSessionValue(Constants::PHONE_ERROR) ?>
                        </div>
                    </div>
                    <div class="inputBx">
                        <span>Description</span>
                        <textarea type="message" name="descriptionAsp"
                            value="<?php printSessionValue(Constants::CACHE_DESCRIPTION) ?>"></textarea>
                        <div class="inputMessage">
                            <?php printSessionValue(Constants::DESCRIPTION_ERROR) ?>
                        </div>
                    </div>


                    <div class="inputBx">
                        <input type="submit" value="ADD" name="btnAddAsp">
                    </div>
                </form>

            </div>
        </div>

        <?php include('../component/footer.php'); ?>
</body>
<script src="../component/header.js"></script>
<script src="../js_utils.js"></script>

</html>