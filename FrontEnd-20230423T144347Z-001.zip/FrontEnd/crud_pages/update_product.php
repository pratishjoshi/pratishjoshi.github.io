<?php

namespace model;

include('../all_models.php');

if (isset($_POST['btnUpdateUpp'])) {
    $productName = secure($_POST['productNameUpp']);
    $productPrice = secure($_POST['productPriceUpp']);
    $productQuantity = secure($_POST['productQuantityUpp']);
    $minimumOrder = secure($_POST['minimumOrderUpp']);
    $maximumOrder = secure($_POST['maximumOrderUpp']);
    $productCategory = secure($_POST['productCategoriesUpp']);
    $shopId = secure($_POST['shopNameUpp']);
    $productDescription = secure($_POST['descriptionUpp']);

    $productImage = $_FILES['imageApp'];
    $productImageName = $_FILES['imageApp']['name'];
    $productImageSize = $_FILES['imageApp']['size'];
    $productImageType = $_FILES['imageApp']['type'];
    $productImageTempName = $_FILES['imageApp']['tmp_name'];
    $productImageLocation = '../resources/data/' . $productImageName;

    if (isDetailsValid($productName, $productPrice, $productQuantity, $minimumOrder, $maximumOrder, $productCategory, $shopId, $productDescription, $productImage)) {

        $addProductQuery = "";
        if (
            Dao::executeQuery($addProductQuery)
        ) {
            setsession(Constants::STATUS_SUCCESS, "Product Successfully Added");
        } else {
            setsession(Constants::STATUS_ERROR, "Product could not be added");
        }
    }
    header($SERVER_REFERER);

    print_r($productCategory);
    echo json_encode($productImage) . '<br>';
    echo $productImageName . '<br>';
    echo $productImageTempName . '<br>';
    echo $productImageType . '<br>';
    echo $productImageSize . '<br>';
    echo $productImageLocation . '<br>';
}

function isDetailsValid($productName, $productPrice, $productQuantity, $minimumOrder, $maximumOrder, $productCategory, $shopName, $productDescription, $productImage)
{

    $isValidProductName = validateEmpty($productName, Constants::PRODUCT_NAME_ERROR, "Please enter the product name");
    $isValidProductPrice = validateEmpty($productPrice, Constants::PRODUCT_PRICE_ERROR, "Please enter your product price");
    if ($isValidProductPrice) {
        if ($productPrice < 0) {
            setsession(Constants::PRODUCT_PRICE_ERROR, "Please enter a valid price");
        }
    }

    $isValidProductQuantity = validateEmpty($productQuantity, Constants::PRODUCT_QUANTITY_ERROR, "Please enter your product quantity");
    if ($isValidProductQuantity) {
        if ($productQuantity < 0) {
            setsession(Constants::PRODUCT_QUANTITY_ERROR, "Please enter a valid quantity");
        }
    }

    $isValidMinimumOrder = validateEmpty($minimumOrder, Constants::MINIMUM_ORDER_ERROR, "Please enter your minimum order");
    if ($isValidMinimumOrder) {
        if ($minimumOrder < 1) {
            setsession(Constants::MINIMUM_ORDER_ERROR, "Please enter a valid minimum order");
        }
    }

    $isValidMaximumOrder = validateEmpty($maximumOrder, Constants::MAXIMUM_ORDER_ERROR, "Please enter your maximum order");
    if ($isValidMaximumOrder) {
        if ($maximumOrder < $minimumOrder) {
            setsession(Constants::MAXIMUM_ORDER_ERROR, "Maximum order cannot be less than minimum order");
        }
    }

    $isValidShopName = validateEmpty($shopName, Constants::SHOP_NAME_ERROR, "Please select your shop");
    $isValidProductDescription = validateEmpty($productDescription, Constants::DESCRIPTION_ERROR, "Please enter your product description");
    $isValidProductImage = isValidImage($productImage);

    return $isValidProductName and $isValidProductPrice and $isValidProductQuantity and $isValidMinimumOrder and $isValidMaximumOrder and $isValidShopName and $isValidProductDescription and $isValidProductImage;
}
