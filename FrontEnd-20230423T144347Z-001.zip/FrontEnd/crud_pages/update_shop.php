<?php

namespace model;

include('../all_models.php');

if (isset($_POST['btnUPDATEUsp'])) {
    $SERVER_REFERER = "Location: {$_SERVER['HTTP_REFERER']}";
    $shopName = secure($_POST['shopNameUsp']);
    $shopEmail = secure($_POST['emailUsp']);
    $phone = secure($_POST['phoneUsp']);
    $description = secure($_POST['descriptionUsp']);

    if (isDetailsValid($shopName, $shopEmail, $phone, $description)) {
    }
    header($SERVER_REFERER);
}

function isDetailsValid($name, $email, $phone, $description)
{
    $isNameValid = validateEmpty($name, Constants::SHOP_NAME_ERROR, "Please enter your shop name");
    $isEmailValid = empty($email);
    if (!$isEmailValid) {
        $isEmailValid = isValidEmail($email);
    }
    $isPhoneValid = empty($phone);
    if (!$isPhoneValid) {
        $isPhoneValid = isValidPhone($phone);
    }
    $isDescriptionValid = validateEmpty($description, Constants::DESCRIPTION_ERROR, "Please enter your shop description");

    return $isNameValid and $isDescriptionValid;
}
