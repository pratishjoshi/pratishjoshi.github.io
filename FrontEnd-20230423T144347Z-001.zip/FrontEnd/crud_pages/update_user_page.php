<?php
namespace model;

include('../all_models.php');
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php include('../common_links.php'); ?>
    <title>Update User</title>
</head>

<body class="2xl:container mx-auto justify-center">
    <?php include('../component/header.php'); ?>

    <div class="flex flex-row flex-wrap items-center justify-center mt-[32px] min-h-[1024px] max-h-[1024px]">

        <div class="basis-1/2 hidden lg:block">

            <!-- Put image here -->
            <img class="object-cover rounded-[16px] h-[1024px]" src="../resources/img_customer_register.jpg" alt="Display Image">

        </div>

        <!-- remove form-content and replace with the below line of code -->
        <div class="basis-[100%] lg:basis-1/2 max-h-[1024px] overflow-y-auto">

            <!-- remove form and replace with the below line of code -->
            <div class="w-[100%] px-[32px] lg:px-[64px]">

                <!-- Everything else is same just copy your content inside of form and paste here -->
                <div class="form-intro">
                    Update User Detail
                </div>
                <?php
                echo showAlert(printSessionValue(Constants::STATUS_ERROR));
                ?>
                <form action="update_user_page.php" method="POST">

                    <div class="inputBx">
                        <span>Full Name</span>
                        <input type="text" name="fullnameUup"
                            value="<?php printSessionValue(Constants::CACHE_FULL_NAME) ?>">
                        <div class="inputMessage">
                            <?php printSessionValue(Constants::FULL_NAME_ERROR) ?>
                        </div>
                    </div>
                    <div class="inputBx">
                        <span>Phone Number</span>
                        <input type="number" name="phoneUup" value="<?php printSessionValue(Constants::CACHE_PHONE) ?>">
                        <div class="inputMessage">
                            <?php printSessionValue(Constants::PHONE_ERROR) ?>
                        </div>
                    </div>

                    <!-- Add Age and Gender here -->
                    <div class="flex flex-row justify-between mt-[-24px] mb-[-24px]">
                        <div class="w-[45%] inputBx">
                            <span>Age</span>
                            <input type="number" name="ageUup" value="<?php printSessionValue(Constants::CACHE_AGE) ?>">
                            <div class="inputMessage">
                                <?php printSessionValue(Constants::AGE_ERROR) ?>
                            </div>
                        </div>
                        <div class="w-[45%] inputBx">
                            <span>Gender</span>
                            <select name="genderTr">
                                <option value="male" <?php
                                if (getSessionValue(Constants::CACHE_GENDER) == "male") {
                                    echo "selected";
                                }
                                ?>>Male</option>
                                <option value="female" <?php
                                if (getSessionValue(Constants::CACHE_GENDER) == "female") {
                                    echo "selected";
                                }
                                ?>>Female</option>
                            </select>
                        </div>
                    </div>

                    <div class="inputBx">
                        <span>Email</span>
                        <input type="email" name="emailUup" value="<?php printSessionValue(Constants::CACHE_EMAIL) ?>">
                        <div class="inputMessage">
                            <?php printSessionValue(Constants::EMAIL_ERROR) ?>
                        </div>
                    </div>
                    <div class="inputBx">
                        <span>New Password</span>
                        <input type="password" name="newPasswordUup">
                        <div class="inputMessage">
                            <?php printSessionValue(Constants::NEW_PASSWORD_ERROR) ?>
                        </div>
                    </div>
                    <div class="inputBx">
                        <span>Current Password</span>
                        <input type="password" name="currentPasswordUup" placeholder="Optional">
                        <div class="inputMessage">
                            <?php printSessionValue(Constants::CURRENT_PASSWORD_ERROR) ?>
                        </div>
                    </div>
                    <div class="inputBx">
                        <input type="submit" value="UPDATE" name="btnUpdateUup">
                    </div>
                </form>
            </div>
        </div>
        <?php include('../component/footer.php'); ?>
</body>
<script src="../js_utils.js"></script>

</html>