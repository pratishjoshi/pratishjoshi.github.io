<?php
namespace model;

include('../all_models.php');

if (isset($_POST['btnCreateAnAccountCr'])) {
    $SERVER_REFERER = "Location: {$_SERVER['HTTP_REFERER']}";
    $fullname = secure($_POST['fullnameCr']);
    $email = secure($_POST['emailCr']);
    $phone = secure($_POST['phoneCr']);
    $password = secure($_POST['passwordCr']);
    $age = secure($_POST['ageCr']);
    $gender = secure($_POST['genderCr']);

    if (isRegistrationDetailsValid($fullname, $email, $phone, $password, $age, $gender)) {
        $firstname = getFirstAndLastname(ucwords($fullname))['firstname'];
        $lastname = getFirstAndLastname(ucwords($fullname))['lastname'];
        $user = new User(-1, $firstname, $lastname, $phone, $email, $age, $gender, md5($password), "customer");
        setsession(Constants::CACHE_USER_DETAILS, serialize($user));
        Mailer::sendVerificationEmail($email, 'customer_registration');
    }

    header($SERVER_REFERER);
}

if (isset($_GET['action']) && $_GET['action'] == "registration_auth") {
    if (isset($_GET['authKey']) && $_GET['authKey'] == $_COOKIE[Constants::ONE_TIME_PASSWORD]) {
        performRegistration();
    } else {
        invalidLink();
    }
}

function invalidLink()
{
    setsession(Constants::MAILER_STATUS_ERROR, "Invalid URL. Please try to register again.");
    removemultiplesession(array(Constants::CACHE_USER_DETAILS, Constants::CACHE_GENDER));
    header("Location:../customer_registration/customer_registration_page.php");
}
function performRegistration()
{
    $user = unserialize(getSessionValue(Constants::CACHE_USER_DETAILS));

    if (
        Dao::addRecord(
            "USERS",
            array(
                "F_NAME" => $user->firstname,
                "L_NAME" => $user->lastname,
                "AGE" => $user->age,
                "EMAIL" => $user->email,
                "PHONE" => $user->phone,
                "GENDER" => $user->gender,
                "PASSWORD" => $user->password,
                "ROLE" => $user->role,
            )
        )
    ) {
        setcookie(Constants::LOGGED_IN_USER, serialize($user), time() + (86400), "/");
        removemultiplesession(array(Constants::CACHE_USER_DETAILS, Constants::CACHE_GENDER));
        setsession(Constants::MAILER_STATUS_SUCCESS, "You have been registered. Please log in.");
        header("Location:../login/login_page.php");
    } else {
        setsession(Constants::MAILER_STATUS_ERROR, "Could not register you. Please try again");
        removemultiplesession(array(Constants::CACHE_USER_DETAILS, Constants::CACHE_GENDER));
        header("Location:../customer_registration/customer_registration_page.php");
    }
}

function isRegistrationDetailsValid($fullname, $email, $phone, $password, $age, $gender): bool
{
    $isvalidfullname = isValidFullName($fullname);
    $isvalidphone = isValidPhone($phone);
    $isvalidemail = isValidEmail($email);
    $isvalidpassword = isValidPassword($password);
    $isvalidage = isValidAge($age);

    $isValid = $isvalidfullname && $isvalidphone && $isvalidpassword && $isvalidemail && $isvalidage;
    if (!$isValid) {
        setsession(Constants::CACHE_FULL_NAME, $fullname);
        setsession(Constants::CACHE_EMAIL, $email);
        setsession(Constants::CACHE_PHONE, $phone);
        setsession(Constants::CACHE_AGE, $age);
        setsession(Constants::CACHE_GENDER, $gender);
    }
    return $isValid;
}
?>