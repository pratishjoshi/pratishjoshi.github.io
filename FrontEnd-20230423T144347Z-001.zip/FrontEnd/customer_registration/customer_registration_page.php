<?php
namespace model;

include('../all_models.php');
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="../styles.css">
    <title>Customer Registration</title>
</head>

<body>
    <section>
        <div class="form-image">
            <img src="../resources/img_customer_register.jpg" alt="Display Image">
        </div>
        <div class="form-content">
            <div class="form">

                <div class="form-intro">
                    Welcome to <span style="cursor:pointer" onclick="redirectToIndex()">Freeman</span>,<br>Shop With Us.
                </div>
                <div class="form-introDesc">
                    <div>Want to sell with us? <a class="underline"
                            href="../trader_registration/trader_registration_page.php">Create a
                            trader account</a></div>
                    <div>It takes less than a minute.</div>
                </div>


                <?php
                echo showSuccess(printSessionValue(Constants::MAILER_STATUS_SUCCESS));
                echo showAlert(printSessionValue(Constants::MAILER_STATUS_ERROR));
                ?>

                <form action="customer_registration.php" method="POST">

                    <div class="inputBx">
                        <span>Full Name</span>
                        <input type="text" name="fullnameCr"
                            value="<?php printSessionValue(Constants::CACHE_FULL_NAME) ?>">
                        <div class="inputMessage">
                            <?php printSessionValue(Constants::FULL_NAME_ERROR) ?>
                        </div>
                    </div>
                    <div class="inputBx">
                        <span>Phone Number</span>
                        <input type="number" name="phoneCr" value="<?php printSessionValue(Constants::CACHE_PHONE) ?>">
                        <div class="inputMessage">
                            <?php printSessionValue(Constants::PHONE_ERROR) ?>
                        </div>
                    </div>

                    <!-- Add Age and Gender here -->
                    <div class="flex flex-row justify-between mt-[-24px] mb-[-24px]">
                        <div class="w-[45%] inputBx">
                            <span>Age</span>
                            <input type="number" name="ageCr" value="<?php printSessionValue(Constants::CACHE_AGE) ?>">
                            <div class="inputMessage">
                                <?php printSessionValue(Constants::AGE_ERROR) ?>
                            </div>
                        </div>
                        <div class="w-[45%] inputBx">
                            <span>Gender</span>
                            <select name="genderCr">
                                <option value="male" <?php
                                if (getSessionValue(Constants::CACHE_GENDER) == "male") {
                                    echo "selected";
                                }
                                ?>>Male</option>
                                <option value="female" <?php
                                if (getSessionValue(Constants::CACHE_GENDER) == "female") {
                                    echo "selected";
                                }
                                ?>>Female</option>
                            </select>
                        </div>
                    </div>

                    <div class="inputBx">
                        <span>Email</span>
                        <input type="email" name="emailCr" value="<?php printSessionValue(Constants::CACHE_EMAIL) ?>">
                        <div class="inputMessage">
                            <?php printSessionValue(Constants::EMAIL_ERROR) ?>
                        </div>
                    </div>
                    <div class="inputBx">
                        <span>Password</span>
                        <input type="password" name="passwordCr">
                        <div class="inputMessage">
                            <?php printSessionValue(Constants::PASSWORD_ERROR) ?>
                        </div>
                    </div>

                    <div class="inputBx form-remDiv">
                        <div>Already have an account?&nbsp;
                            <a class="underline" href="../login/login_page.php">Login</a>
                        </div>
                    </div>
                    <div class="inputBx" style="margin-top:-32px">
                        <input type="submit" value="Create an account" name="btnCreateAnAccountCr">
                    </div>
                </form>
            </div>
        </div>
</body>
<script src="../js_utils.js"></script>

</html>