<?php
namespace model;

include('../all_models.php');

$SERVER_REFERER = "Location: {$_SERVER['HTTP_REFERER']}";
$action = "none";
if (isset($_GET['action'])) {
    $action = $_GET['action'];
}

if ($action == "add") {
    if (isset($_GET['id'])) {
        $id = $_GET['id'];
        $user = getUserDetails();
        if ($user != null) {
            
        } else {
            $favouriteItems = array();
            if (getCookieValue(Constants::CACHE_GUEST_FAVOURITES) != null) {
                $favouriteItems = json_decode(getCookieValue(Constants::CACHE_GUEST_FAVOURITES));
            }
            array_unshift($favouriteItems, $id);
            setcookie(Constants::CACHE_GUEST_FAVOURITES, json_encode($favouriteItems), 86400, "/");
        }
    }
}

if ($action == "remove") {
    if (isset($_GET['id'])) {
        $id = $_GET['id'];
        $user = getUserDetails();
        if ($user != null) {

        } else {
            $favouriteItems = array();
            if (getCookieValue(Constants::CACHE_GUEST_FAVOURITES) != null) {
                $favouriteItems = json_decode(getCookieValue(Constants::CACHE_GUEST_FAVOURITES));
            }
            array_shift($favouriteItems);
            setcookie(Constants::CACHE_GUEST_FAVOURITES, json_encode($favouriteItems), 86400, "/");
        }
    }

    header($SERVER_REFERER);
}

?>