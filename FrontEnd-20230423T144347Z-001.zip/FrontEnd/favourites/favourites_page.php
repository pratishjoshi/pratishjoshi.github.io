<?php
namespace model;

include('../all_models.php');
$user = null;
if (getLoggedInType() == "customer") {
    $user = unserialize(getCookieValue(Constants::LOGGED_IN_USER));
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Favorites</title>
    <?php require('../common_links.php'); ?>
</head>

<body class="2xl:container mx-auto">
    <?php include('../component/header.php'); ?>
    <div class="lexend-medium text-[48px] my-[32px]">Favorites</div>
    <div class="flex flex-col flex-wrap gap-[32px]">
        <?php
        if ($user == null) {
            $favouriteItem = array();
            if (getCookieValue(Constants::CACHE_GUEST_FAVOURITES) != null) {
                $favouriteItem = json_decode(getCookieValue(Constants::CACHE_GUEST_FAVOURITES));
            }
            $query = "SELECT PRODUCT_ID, NAME, DESCRIPTION, PRICE, IMAGE FROM PRODUCT WHERE 1!=1 ";
            foreach ($favouriteItem as $item) {
                $query = "OR PRODUCT_ID = " . $item . " ";
            }
        } else {
            $query = "SELECT p.PRODUCT_ID, p.NAME, p.IMAGE, p.DESCRIPTION, p.PRICE, p.QUANTITY, ci.QUANTITY
                    FROM FAVORITE f
                    JOIN FAVORITE_ITEM fi ON f.FAVORITE_ID = fi.FAVORITE_ID
                    JOIN product p ON fi.PRODUCT_ID = p.PRODUCT_ID
                    WHERE f.USER_ID = $user->id;
                    ";
        }
        horizontal_product_card_favourites();
        horizontal_product_card_favourites();
        horizontal_product_card_favourites();
        ?>
    </div>

    <div class="lexend-medium text-[36px] mt-[32px]">Similar Product</div>
    <div class="flex flex-row overflow-auto gap-[32px] mt-[16px]">
        <?php
        vertical_product_card();
        vertical_product_card();
        vertical_product_card();
        vertical_product_card();
        vertical_product_card();
        vertical_product_card();
        vertical_product_card();
        vertical_product_card();
        ?>
    </div>

    <?php include('../component/footer.php'); ?>
</body>
<script src="../component/header.js"></script>
<script src="../js_utils.js"></script>

</html>