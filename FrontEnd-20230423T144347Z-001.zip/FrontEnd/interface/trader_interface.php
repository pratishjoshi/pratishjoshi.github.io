<?php
namespace model;

include('../all_models.php');
if (getLoggedInType() != "trader") {
    header("location:../index.php");
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Trader Interface</title>
    <?php require('../common_links.php'); ?>
</head>

<body class="2xl:container mx-auto px-[16px]">

    <?php
    include('../component/header.php');
    ?>

    <div class="flex justify-center">
        <div class="grid grid-cols-2 gap-[3.33vw]">
            <?php
            interface_card("../resources/img_product.jpg", "PRODUCTS", "../table_page/products_table.php");
            interface_card("../resources/img_shop.jpg", "SHOPS", "../table_page/shops_table.php");
            interface_card("../resources/img_order.jpg", "ORDER", "../table_page/order_table.php");
            interface_card("../resources/img_report.jpg", "REPORT", "#../table_page/report_table.php");
            interface_card("../resources/img_oracle.jpg", "ORACLE", "#");
            ?>
        </div>
    </div>

    <?php include('../component/footer.php'); ?>

</body>
<script src="../component/header.js"></script>
<script src="../js_utils.js"></script>

</html>