<?php
namespace model;

include('../all_models.php');
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php include('../common_links.php'); ?>
    <link rel="stylesheet" href="invoice.css">
    <title>Invoice</title>
</head>

<body class="2xl:container mx-auto px-[16px]">

    <?php include('../component/header.php'); ?>

    <div class="flex flex-col mx-auto my-[32px] p-[16px]  w-[21cm] h-[29.7cm] border-[1px] border-black">

        <!-- Header In Invoice -->
        <div class="flex justify-between align-center items-center">
            <div class="flex-col">
                <div class="text-xl font-normal">Cleckhudderfax</div>
                <div class="text-lg font-light">West Yorkshire, UK</div>
            </div>
            <img src="../resources/LogoDark.svg" alt="Logo">
        </div>

        <div class="text-2xl font-normal mt-[16px]">Invoice</div>
        <div class="text-xl font-normal mt-[16px]">BILL TO</div>

        <!-- Bill To Contents  -->
        <div class="flex flex-col mb-[16px]">
            <div class="flex justify-between">
                <div class="font-light text-lg">Sushant Neupane</div>
                <div class="font-light text-lg">Invoice No : 123-456-789</div>
            </div>
            <div class="flex justify-between">
                <div class="font-light text-lg">User Description</div>
                <div class="font-light text-lg">Date : 01/01/1970</div>
            </div>
        </div>

        <!-- Order details -->
        <?php

        // Perform these on top
        $titles = array("S.N" => "sn", "Product Name" => "name", "Seller/Buyer" => "trader", "Quantity" => "quantity", "Price" => "price", "Total" => "total");
        $values = array(
            array("sn" => 1, "name" => "Name", "trader" => "Name", "quantity" => "#", "price" => "#", "total" => "#")
        );

        cart_table($titles, $values);
        ?>

        <!-- Footer  -->
        <div class="flex justify-between mt-auto">
            <div class="flex align-center items-center gap-[8px]">
                <i class="bi bi-telephone" class="text-md font-light"></i>
                <a href="tel:+977 9823123458" class="font-light text-md">+977 9823123458</a>
            </div>
            <div class="flex align-center items-center gap-[8px]">
                <i class="bi bi-envelope" class="text-md font-light"></i>
                <a href="mailto:freemanurbanstore@gmail.com" class="font-light text-md">freemanurbanstore@gmail.com</a>
            </div>
        </div>

    </div>

    <?php include('../component/footer.php'); ?>

</body>
<script src="../component/header.js"></script>
<script src="../js_utils.js"></script>
<script src="../product/filter.js"></script>

</html>