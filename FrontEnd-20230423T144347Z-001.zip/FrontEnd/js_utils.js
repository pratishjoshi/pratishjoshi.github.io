let permission = Notification.permission;

function productDetail(id) {
    window.location.href = "../product_detail/product_detail_page.php?productId=" + id;
}

function redirectToIndex() {
    window.location.href = "../component/homepage.php";
}

function redirectToAboutUs() {
    window.location.href = "../about_us/about_us.php";
}

function redirectToContactUs() {
    window.location.href = "../contact_us/contact_us_page.php";
}
function logOutClick() {
    var doLogOut = window.confirm("Are you sure you want to log out?");
    if (doLogOut) {
        window.location.href = "../component/logout.php";
    }
}

function redirectToFavourites() {
    window.location.href = "../favourites/favourites_page.php";
}

function addToCart(id) {
    event.stopPropagation();
    const xhr = new XMLHttpRequest();
    xhr.open('GET', `../cart/cart.php?action=add&id=` + id, true);
    xhr.onload = () => {
        if (xhr.status === 200) {
            alert("Item is added to cart")
        } else {
            alert("Item could not be added to cart");
        }
    };
    xhr.send();
}

function removeFromCart(id) {
    event.stopPropagation();
    const xhr = new XMLHttpRequest();
    xhr.open('GET', `../cart/cart.php?action=remove&id=` + id, true);
    xhr.onload = () => {
        if (xhr.status === 200) {
            alert("Item is removed from cart");
        } else {
            alert("Item could not be removed from cart");
        }
    };
    xhr.send();
}

function addToFavourites(id) {
    event.stopPropagation();
    const xhr = new XMLHttpRequest();
    xhr.open('GET', `../favourites/favourites.php?action=add&id=` + id, true);
    xhr.onload = () => {
        if (xhr.status === 200) {
            alert("Item is added to favourites");
        } else {
            alert("Item could not be added to favourites");
        }
    };
    xhr.send();
}

function removeFromFavourites(id) {
    event.stopPropagation();
    const xhr = new XMLHttpRequest();
    xhr.open('GET', `../favourites/favourites.php?action=remove&id=` + id, true);
    xhr.onload = () => {
        if (xhr.status === 200) {
            alert("Item is removed from favourites");
        } else {
            alert("Item could not be removed from favourites");
        }
    };
    xhr.send();
}

function notification(message) {
    if (permission === "granted") {
        showNotification(message);
    } else if (permission === "default") {
        requestPermission(message);
    } else {
        alert(message);
    }
}

function requestPermission(message) {
    Notification.requestPermission((permission) => {
        notification(message)
    })
}

function showNotification(message) {
    let title = "Freeman Urban Store";
    let icon = "../resources/LogoDark.svg";
    var notification = new Notification(title, { message, icon })
    notification.onclick = () => {
        notification.close;
        window.parent.focus();
    }
}

function quantityIncrease(id, maximumOrder) {
    let quantityCount = document.getElementById(id)
    event.stopPropagation
    let value = parseInt(quantityCount.innerText);
    if (value == maximumOrder) {
        alert('Maximum Quantity of Product is ' + maximumOrder);
    } else {
        value++;
        quantityCount.innerText = value;
    }
}

function quantityDecrease(id, minimumOrder) {
    let quantityCount = document.getElementById(id)
    event.stopPropagation
    let value = parseInt(quantityCount.innerText);
    if (value == minimumOrder) {
        alert('Minimum Quantity of Product is ' + minimumOrder);
    } else {
        value--;
        quantityCount.innerText = value;
    }
}
