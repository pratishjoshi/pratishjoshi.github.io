<?php
namespace model;

include('../all_models.php');
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="../styles.css">
    <title>Forgot Password</title>
</head>

<body style="height:100vh" class="flex items-center">
    <div class="container mx-auto flex flex-col justify-center max-w-[425px] p-[16px]">
        <div class="cursor-pointer lexend-regular text-[36px]" onclick="redirectToIndex()">Freeman Urban Store,</div>
        <div class="lexend-regular text-[36px]">Password Reset</div>
        <?php
        echo showAlert(getSessionValue(Constants::EMAIL_ERROR));
        removesession(Constants::EMAIL_ERROR);
        ?>

        <form action="" method="POST" class="max-w-[400px]">
            <div class="inputBx">
                <span>You have been verified.
                    <br>Enter your new password.</span>
                <input type="password" name="passwordFp" placeholder="New Password">
                <div class="inputMessage">
                </div>
            </div>
            <div class="inputBx">
                <span></span>
                <input type="password" name="repasswordFp" placeholder="Re-New Password">
                <div class="inputMessage">
                </div>
            </div>
            
            <div class="inputBx" style="margin-top:-32px">
                <input type="submit" value="CONFIRM" name="btnConfirmFp">
            </div>
        </form>

    </div>
</body>
<script src="../js_utils.js"></script>
<?php
?>

</html>