<?php
namespace model;

include('../all_models.php');


$SERVER_REFERER = "Location: {$_SERVER['HTTP_REFERER']}";
if (isset($_POST['btnSignInLogin'])) {
    session_start_by_check();
    $email = secure($_POST['emailLogin']);
    $password = md5(secure($_POST['passwordLogin']));
    $rememberMe = 'off';
    if (isset($_POST['rememberMeLogin'])) {
        $rememberMe = $_POST['rememberMeLogin'];
    }

    $query = "SELECT * FROM USERS WHERE EMAIL = '$email' AND PASSWORD = '$password' ";
    $result = Dao::executeQueryForResult($query);
    if ($result) {
        $user = new User(
            $result['USER_ID'],
            $result['F_NAME'],
            $result['L_NAME'],
            $result['PHONE'],
            $result['EMAIL'],
            $result['AGE'],
            $result['GENDER'],
            $result['PASSWORD'],
            $result['ROLE']
        );
    }

    if (isset($user)) {
        Mailer::sendOTPEmail($user->email);
        removesession(Constants::MAILER_STATUS_SUCCESS);
        setsession(Constants::CACHE_USER_DETAILS, serialize($user));
        header('Location: otp_page.php?rememberMe=' . $rememberMe);
    } else {
        $_SESSION[Constants::LOGIN_ERROR] = "Invalid Username or Password";
        header($SERVER_REFERER);
    }

}
?>