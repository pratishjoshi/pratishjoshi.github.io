<?php
namespace model;

include('../all_models.php');
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="../styles.css">
    <title>Login</title>
</head>

<body>
    <section>
        <div class="form-image">
            <img src="../resources/img_login.jpg" alt="Display Image">
        </div>
        <div class="form-content">
            <div class="form">
                <div class="form-intro">
                    Welcome to <span style="cursor:pointer" onclick="redirectToIndex()">Freeman</span>,<br>Sign In to
                    Continue.
                </div>
                <div class="form-introDesc">
                    <div>Don't have an account? <a class="underline"
                            href="../customer_registration/customer_registration_page.php">Create
                            an account</a></div>
                    <div>It takes less than a minute.</div>
                </div>
                <?php
                echo showAlert(getSessionValue(Constants::LOGIN_ERROR));
                removesession(Constants::LOGIN_ERROR);
                ?>
                <form action="login.php" method="POST">
                    <div class="inputBx">
                        <span>Email</span>
                        <input type="email" name="emailLogin">
                    </div>
                    <div class="inputBx">
                        <span>Password</span>
                        <input type="password" name="passwordLogin">
                    </div>
                    <div class="inputBx form-remDivSpaceBetween">
                        <div class="flex flex-row align-center items-center gap-1">
                            <input class="max-h-[18px] max-w-[18px]" type="checkbox" name="rememberMeLogin">
                            <label>Remember me</label>
                        </div>
                        <a href="forgot_password_email_page.php" class="forgot">Forgot Password?</a>
                    </div>
                    <div class="inputBx">
                        <input type="submit" value="Sign In" name="btnSignInLogin">
                    </div>
                </form>
            </div>
        </div>
    </section>
</body>
<script src="../js_utils.js"></script>

</html>