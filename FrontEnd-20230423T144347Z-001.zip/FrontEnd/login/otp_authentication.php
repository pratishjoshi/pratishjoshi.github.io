<?php
namespace model;

include('../all_models.php');


$SERVER_REFERER = "Location: {$_SERVER['HTTP_REFERER']}";
if (isset($_POST['btnVerifyOTP'])) {
    $isRemember = 'off';
    if (isset($_GET['rememberMe'])) {
        $isRemember = $_GET['rememberMe'];
    }
    $otpValue = secure($_POST['otpValue']);

    if (getCookieValue(Constants::ONE_TIME_PASSWORD) == $otpValue) {
        $user = unserialize(getSessionValue(Constants::CACHE_USER_DETAILS));
        if ($user instanceof User) {
            if ($rememberMe == 'on') {
                setcookie(Constants::LOGGED_IN_USER, serialize($user), time() + (86400 * 28), "/");
            } else {
                setcookie(Constants::LOGGED_IN_USER, serialize($user), time() + (86400), "/");
            }
            removesession(Constants::CACHE_USER_DETAILS);
            header("Location:/index.php");
        }
    } else {
        setsession(Constants::LOGIN_ERROR, "Invalid One Time Password");
        header($SERVER_REFERER);
    }

    function setGuestFavouritesAndCartItems($id){
        $guestCart = array();
        $guestFavourites = array();
        $user = unserialize(getSessionValue(Constants::CACHE_USER_DETAILS));

        if(getCookieValue(Constants::CACHE_GUEST_CART) != null){
            $guestCart = json_decode(getCookieValue(Constants::CACHE_GUEST_CART));
            // Insert item to user cart
            foreach($guestCart as $item){

            }
            removeCookie($guestCart);
        }
        if(getCookieValue(Constants::CACHE_GUEST_FAVOURITES)!= null){
            $guestFavourites = json_decode(getCookieValue(Constants::CACHE_GUEST_FAVOURITES));
            // Insert item to user favourites
            foreach($guestFavourites as $item){
                
            }
            removeCookie($guestFavourites);
        }


    }
}
?>