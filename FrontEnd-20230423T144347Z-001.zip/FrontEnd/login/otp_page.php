<?php 
namespace model;

include('../all_models.php');
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="../styles.css">
    <title>One Time Password</title>
</head>

<body style="height:100vh" class="flex items-center">
    <div class="container mx-auto flex flex-col justify-center max-w-[400px] p-[16px]">
        <img class="cursor-pointer" src="../resources/LogoDark.svg" alt="Store Logo" onclick="redirectToIndex()">

        <?php
        echo showAlert(getSessionValue(Constants::LOGIN_ERROR));
        removesession(Constants::LOGIN_ERROR);
        ?>

        <div style="margin-top:24px" class="text-l self-center">OTP has been sent to your email</div>
        <form action="otp_authentication.php" method="POST" class="max-w-[400px]">
            <input type="hidden" name="rememberMe" value="<?php
            if (isset($_GET['rememberMe'])) {
                echo $_GET['rememberMe'];
            }
            ?>">
            <div class="inputBx">
                <input type="number" name="otpValue" placeholder="Enter your OTP password">
            </div>

            <div class="inputBx form-remDiv">
                <div>Didn't recieve a code?&nbsp;
                    <a class="underline" href="#">Resend</a>
                </div>
            </div>
            <div class="inputBx" style="margin-top:-32px">
                <input type="submit" value="VERIFY" name="btnVerifyOTP">
            </div>
        </form>
    </div>
</body>
<script src="../js_utils.js"></script>

</html>