<?php
namespace model;

Dao::init();

class Dao
{
    private static $conn;
    private static $idToTable = array(
        "USERS" => "USER_ID"
    );

    public static function init()
    {
        self::$conn = oci_connect("admin", "Sushant123!", "//localhost/xe");
    }

    public static function addRecord($table, $data)
    {
        $keys = array_keys($data);
        $values = array_map(function ($value) {
            return "'$value'";
        }, array_values($data));
        $fields = implode(',', $keys);
        $values = implode(',', $values);
        $query = "INSERT INTO $table ($fields) VALUES ($values)";
        return self::executeQuery($query);
    }

    public static function deleteRecord($table, $id)
    {
        $idName = self::getIdNameFromTable($table);
        $query = "DELETE FROM $table WHERE  $idName = $id";
        return self::executeQuery($query);
    }

    public static function updateRecord($table, $id, $data)
    {
        $idName = self::getIdNameFromTable($table);
        $setValues = '';
        foreach ($data as $key => $value) {
            $setValues .= "$key = '$value',";
        }
        $query = "UPDATE $table SET $setValues WHERE $idName = $id";
        return self::executeQuery($query);
    }

    public static function executeQueryForResult($query)
    {
        $stid = oci_parse(self::$conn, $query);
        $res = oci_execute($stid);
        if (!$res) {
            return false;
        }

        $result = oci_fetch_array($stid, OCI_ASSOC + OCI_RETURN_NULLS);
        oci_free_statement($stid);

        if (isValidDataArray($result)) {
            return $result;
        }

        return false;
    }

    public static function executeQuery($query): bool
    {
        $stid = oci_parse(self::$conn, $query);
        $res = oci_execute($stid);
        oci_free_statement($stid);
        return $res;
    }

    public static function getIdNameFromTable($table)
    {
        return self::$idToTable[$table];
    }
}
?>