<?php
namespace model;

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
use PHPMailer\PHPMailer\SMTP;

require '../phpmailer/src/Exception.php';
require '../phpmailer/src/PHPMailer.php';
require '../phpmailer/src/SMTP.php';

Mailer::init();
class Mailer
{
    private static $mailer;

    public static $authenticationKey = "-1";

    public static function init()
    {
        self::$mailer = new PHPMailer();
        self::setupMailer();
    }
    private static function setupMailer()
    {
        self::$mailer->isSMTP();
        self::$mailer->Host = 'smtp.gmail.com';
        self::$mailer->SMTPAuth = true;
        self::$mailer->Username = 'nsushant21@tbc.edu.np';
        self::$mailer->Password = 'Adrastea@09';
        self::$mailer->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        self::$mailer->Port = 587;
    }

    private static function generateAuthenticationKey()
    {
        self::$authenticationKey = str_pad(rand(0, 999999), 6, "0", STR_PAD_LEFT);
    }
    private static function generateVerificationEmail($registrationType)
    {
        self::generateAuthenticationKey();
        $address = 'http://localhost:8888/' . $registrationType . '/' . $registrationType . '.php';
        $registrationLink = createPostUrl(
            $address,
            array(
                "action" => "registration_auth",
                "authKey" => self::$authenticationKey
            )
        );
        return '
        <h2>Verify Your Email Address</h2>
        <p>Thank you for registering with Freeman Urban Store! Please click on the link below to verify your email address:</p>
        <p><a href="' . $registrationLink . '">Click here to register your account</a></p>
        <p>This link is valid for one use only and will expire in 5 minutes.</p>
        <p>If you did not register with our website, please ignore this email.</p>
        <p>Thank you,<br>Freeman Urban Store Team</p>    
        ';
    }

    private static function generateOTPEmail()
    {
        self::generateAuthenticationKey();
        return '
        <h2>Your One-Time Password</h2>
        <p>Use the following one-time password to log in to your account:</p>
        <p><strong>' . self::$authenticationKey . '</strong></p>
        <p>This password is valid for one use only and will expire in 5 minutes.</p>
        <p>If you did not request this password, please contact us immediately.</p>
        <p>Thank you,<br>The Website Team</p>
        ';
    }

    private static function generateContactUsMessage($name, $email, $message)
    {
        return '
        <h2>New Customer Message Received</h2>
        <p><strong>Name:</strong> ' . $name . '</p>
        <p><strong>Email:</strong> ' . $email . '</p>
        <p><strong>Message:</strong></p>
        <p>' . $message . '</p>
        <p>Please respond to this customer as soon as possible.</p>
        <p>Thank you,<br>Freeman Urban Store</p>
';

    }

    private static function generateForgotPasswordMessage($name, $email)
    {
        self::generateAuthenticationKey();
        $address = 'http://localhost:8888/forgot_password_page.php';
        $link = createPostUrl(
            $address,
            array(
                "action" => "forgot_password",
                "email" => $email,
                "auth_key" => self::$authenticationKey
            )
        );
        setcookie(Constants::FORGOT_PASSWORD_KEY, self::$authenticationKey, time() + 86400, "/");

        return '<h1>Forgot Password</h1>
        <p>Dear' . $name . '</p>
        <p>We received a request to reset your password. If you did not request this change, you can safely ignore this email.</p>
        <p>To reset your password, please click on the following link:</p>
        <p><a href="' . $link . '">Reset Password</a></p>
        <p>This link will expire in 24 hours.</p>
        <p>Thank you!</p>';
    }

    //$toEmail => Email Address where verification email is to be sent
    //$registrationType => customer_registration or trader_registration
    public static function sendVerificationEmail($toEmail, $registrationType)
    {
        self::$mailer->setFrom(self::$mailer->Username, Constants::NAME);
        self::$mailer->addAddress($toEmail);
        self::$mailer->Subject = "Freeman Urban Store Registration";
        self::$mailer->msgHTML(self::generateVerificationEmail($registrationType));
        if (self::$mailer->send()) {
            setsession(Constants::MAILER_STATUS_SUCCESS, "Verfication mail sent successfully");
            setcookie(Constants::ONE_TIME_PASSWORD, self::$authenticationKey, time() + 300, "/");
        } else {
            setsession(Constants::MAILER_STATUS_ERROR, "Could not send verification email");
        }
    }

    public static function sendOTPEmail($toEmail)
    {
        self::$mailer->setFrom(self::$mailer->Username, Constants::NAME);
        self::$mailer->addAddress($toEmail);
        self::$mailer->Subject = "Freeman Urban Store Authentication";
        self::$mailer->msgHTML(self::generateOTPEmail());
        if (self::$mailer->send()) {
            setsession(Constants::MAILER_STATUS_SUCCESS, "Verfication mail sent successfully");
            setcookie(Constants::ONE_TIME_PASSWORD, self::$authenticationKey, time() + 300, "/");
        } else {
            setsession(Constants::MAILER_STATUS_ERROR, "Could not send verification email");
        }
    }

    public static function sendContactUsMessage($fromName, $email, $message)
    {
        self::$mailer->setFrom(self::$mailer->Username, $fromName);
        self::$mailer->addAddress(self::$mailer->Username);
        self::$mailer->Subject = "Customer Message";
        self::$mailer->msgHTML(self::generateContactUsMessage($fromName, $email, $message));
        if (self::$mailer->send()) {
            setsession(Constants::MAILER_STATUS_SUCCESS, "Your message has been delivered sucessfully");
        } else {
            setsession(Constants::MAILER_STATUS_ERROR, "Your message could not be delivered.<br>Please try again");
        }
    }

    public static function sendForgotPasswordEmail($toEmail, $toName)
    {
        self::$mailer->setFrom(self::$mailer->Username, Constants::NAME);
        self::$mailer->addAddress($toEmail);
        self::$mailer->Subject = "Forgot Password";
        self::$mailer->msgHTML(self::generateForgotPasswordMessage($toName, $toEmail));
        return self::$mailer->send();
    }

}
?>