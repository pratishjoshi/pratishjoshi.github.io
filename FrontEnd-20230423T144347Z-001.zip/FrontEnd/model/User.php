<?php
namespace model;

/**
 * Summary of User
 */
class User
{
    public $id;
    public $firstname;
    public $lastname;
    public $username;
    public $email;
    public $password;
    public $role;
    public $phone;
    public $age;
    public $gender;

    function __construct($id, $firstname, $lastname, $phone, $email, $age, $gender, $password, $role)
    {
        if ($id != -1) {
            $this->id = $id;
        }
        $this->email = $email;
        $this->password = $password;
        $this->phone = $phone;
        $this->firstname = $firstname;
        $this->lastname = $lastname;
        $this->role = $role;
        $this->age = $age;
        $this->gender = $gender;
    }

}
?>