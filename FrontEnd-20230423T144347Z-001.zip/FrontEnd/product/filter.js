const categoryFilter = document.getElementById('categoryFilter');
const priceFilter = document.getElementById('priceFilter');
const ratingFilter = document.getElementById('ratingFilter');
const sortFilter = document.getElementById('sortFilter');
const filterForm = document.getElementById('filter-form');
const productDisplayContainer = document.querySelector('.products-display-container');

categoryFilter.addEventListener('change', onFilterChange);
priceFilter.addEventListener('change', onFilterChange);
ratingFilter.addEventListener('change', onFilterChange);
sortFilter.addEventListener('change', onFilterChange);

function onFilterChange() {
    $.ajax({
        url: '../product/product_filter.php',
        method: 'GET',
        data: { categoryFilter: categoryFilter.value, priceFilter: priceFilter.value, ratingFilter: ratingFilter.value, sortFilter: sortFilter.value},
        success: function (response) {
            productDisplayContainer.innerHTML = response;
        }
    });
}
