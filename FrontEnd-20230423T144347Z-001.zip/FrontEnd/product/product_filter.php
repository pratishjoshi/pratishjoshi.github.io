<?php
namespace model;

include('../all_models.php');

$searchTitle = "";
if (isset($_GET['searchTitle'])) {
    $searchTitle = $_GET['searchTitle'];
}
$searchTitle = ucfirst($searchTitle);

$categoryFilter = "";
if (isset($_GET['categoryFilter'])) {
    $categoryFilter = $_GET['categoryFilter'];
}

$priceFilter = "";
if (isset($_GET['priceFilter'])) {
    $priceFilter = $_GET['priceFilter'];
}

$ratingFilter = "";
if (isset($_GET['ratingFilter'])) {
    $ratingFilter = $_GET['ratingFilter'];
}

$sortFilter = "";
if (isset($_GET['sortFilter'])) {
    $sortFilter = $_GET['sortFilter'];
}

$sql = "SELECT * FROM products WHERE 1=1";

if (!empty($searchTitle)) {
    $sql .= " AND NAME LIKE '%$searchTitle%'";
}

if (!empty($categoryFilter)) {
    $sql .= " AND category = '$categoryFilter'";
}

if (!empty($priceFilter)) {
    $priceRanges = [
        '<10' => [0, 10],
        '<20' => [0, 20],
        '<50' => [0, 50],
        '<100' => [0, 100],
    ];

    if (isset($priceRanges[$priceFilter])) {
        $range = $priceRanges[$priceFilter];
        $sql .= " AND price >= {$range[0]} AND price < {$range[1]}";
    }
}

if (!empty($ratingFilter)) {
    $sql .= " AND rating = '$ratingFilter'";
}

if (!empty($sortFilter)) {
    switch ($sortFilter) {
        case 'name':
            $sql .= " ORDER BY product_name ASC";
            break;
        case 'price':
            $sql .= " ORDER BY price ASC";
            break;
        case 'rating':
            $sql .= " ORDER BY rating DESC";
            break;
    }
}

echo $sql;
// $response = "";
// $result = Dao::getRecordCustomQuery($sql);
// foreach ($result as $r) {
//     // pass product as arguement
//     $response .= vertical_product_card();
// }
// echo $response;

?>