<?php
namespace model;

include('../all_models.php');
$searchTitle = "";
if (isset($_GET['searchTitle'])) {
    $searchTitle = $_GET['searchTitle'];
}
$searchTitle = ucfirst($searchTitle);
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php include('../common_links.php'); ?>
    <title>
        <?php echo $searchTitle ?>
    </title>
</head>

<body class="2xl:container mx-auto px-[16px]">

    <?php include('../component/header.php'); ?>

    <div class="rubik-regular text-[36px]">Results for "
        <?php echo $searchTitle ?>"
    </div>

    <form method="POST" action="" id="filter-form">
        <div class="flex flex-row flex-wrap justify-center mt-[16px]">
            <div class="filter-outlined">
                <select name="categoryFilter" id="categoryFilter">
                    <option value="" selected>Category</option>
                    <option value="bakery">Bakery</option>
                    <option value="butcher">Butcher</option>
                    <option value="fishmonger">Fishmonger</option>
                    <option value="greengrocer">Greengrocer</option>
                    <option value="delicatessen">Delicatessen</option>
                </select>
            </div>
            <div class="filter-outlined">
                <select name="priceFilter" id="priceFilter">
                    <option value="" selected>Price</option>
                    <option value="<10">
                        < 10</option>
                    <option value="<20">
                        < 20</option>
                    <option value="<50">
                        < 50</option>
                    <option value="<100">
                        < 100</option>
                </select>
            </div>
            <div class="filter-outlined">
                <select name="ratingFilter" id="ratingFilter">
                    <option value="" selected>Rating</option>
                    <option value="one">1</option>
                    <option value="two">2</option>
                    <option value="three">3</option>
                    <option value="four">4</option>
                    <option value="five">5</option>
                </select>
            </div>

            <div class="filter-filled ml-[0px] xl:ml-[16px]">
                <select name="sortFilter" id="sortFilter">
                    <option value="" disabled selected>Sort</option>
                    <option value="name">Name</option>
                    <option value="price">Price</option>
                    <option value="rating">Rating</option>
                </select>
            </div>
        </div>

    </form>

    <div class="flex justify-center">
        <div
            class="products-display-container grid overflow-auto gap-[32px] mt-[32px] grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
            <?php
            vertical_product_card();
            vertical_product_card();
            vertical_product_card();
            vertical_product_card();
            vertical_product_card();
            vertical_product_card();
            vertical_product_card();
            vertical_product_card();
            vertical_product_card();
            vertical_product_card();
            vertical_product_card();
            vertical_product_card();
            vertical_product_card();
            vertical_product_card();
            vertical_product_card();
            vertical_product_card();
            vertical_product_card();
            vertical_product_card();
            vertical_product_card();
            vertical_product_card();
            vertical_product_card();
            vertical_product_card();
            vertical_product_card();
            vertical_product_card();
            ?>
        </div>
    </div>

    <?php include('../component/footer.php'); ?>
    
</body>
<script src="../component/header.js"></script>
<script src="../js_utils.js"></script>
<script src="./filter.js"></script>

</html>