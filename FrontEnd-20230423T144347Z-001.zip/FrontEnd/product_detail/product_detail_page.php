<?php
namespace model;

include('../all_models.php');

// $category = "butcher";

// $recentSearches = array();
// if (getCookieValue(Constants::CACHE_RECENT_SEARCHES) != null) {
//     $recentSearches = json_decode(getCookieValue(Constants::CACHE_RECENT_SEARCHES));
// }
// array_push($recentSearches, $category);
// if(count($recentSearches) > 3){
//     array_shift($recentSearches);
// }
// setcookie(Constants::CACHE_RECENT_SEARCHES, json_encode($recentSearches), time() + 86400 , "/");

removeCookie(Constants::CACHE_RECENT_SEARCHES);

$productId = $_GET['productId'];
$reviewQuery = "SELECT * FROM REVIEW WHERE PRODUCT_ID = $productId";
$productDetailQuery = "SELECT p.*, s.NAME as SHOP_NAME, c.NAME as CATEGORY_NAME, 
FROM PRODUCT p
INNER JOIN SHOP s ON p.SHOP_ID = s.SHOP_ID
INNER JOIN CATEGORY c ON p.CATEGORY_ID = c.CATEGORY_ID
WHERE p.PRODUCT_ID = $productId;";
$reviews = Dao::executeQueryForResult($reviewQuery);
$productDetails = Dao::executeQueryForResult($productDetailQuery);
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Product Detail</title>
    <?php require('../common_links.php'); ?>
</head>

<body class="2xl:container mx-auto px-[16px]">

    <?php include('../component/header.php'); ?>

    <div class="flex felx-row flex-wrap lg:justify-center gap-[64px]  mt-[64px] ">

        <div class="sm:basis-1/2 lg:basis-[30%] 2xl:basis-[45%]">
            <img src="../resources/img_product.jpg" alt="Product Image"
                class="width-[100%] aspect-square object-cover rounded-[8px]">
        </div>

        <div class=" flex flex-column flex-wrap h-auto basis-[100%] lg:basis-[60%] 2xl:basis-[45%]">
            <div class="rubik-medium text-[48px]">
                <?php echo "Fine Wine"; ?>
            </div>
            <div class="text-[24px]">
                <?php echo "Delicatessen"; ?>
            </div>
            <div class="flex flex-row gap-x-[4px] items-center mt-[8px]">
                <?php
                for ($x = 1; $x <= 5; $x++) {
                    echo display_stars();
                }
                ?>
            </div>
            <div class="flex flex-row flex-wrap mt-[16px] items-center gap-[16px]">
                <div>Quantity</div>
                <div class="quantity-selector flex flex-row items-center text-[18px] w-[96px]">
                    <img class="quantity-selector-icon quantity-increase basis-[10%]" src="../resources/ic_plus.svg"
                        alt="Increase" onclick="quantityIncrease('qc-id',20)">
                    <div class="quantity-count basis-[80%] justify-center text-center" id="qc-id">9</div>
                    <img class="quantity-selector-icon quantity-decrease basis-[10%]" src="../resources/ic_minus.svg"
                        alt="Decrease" onclick="quantityDecrease('qc-id',1)">
                </div>
            </div>
            <div class="flex flex-row justify-between items-center">
                <div class="lexend-semibold text-[36px]">
                    <?php
                    echo "$200.48";
                    ?>
                </div>
                <div class="text-[16px] mr-[8px] rubik-regular rounded-[4px] bg-[#d6275010] text-[#d62750] p-[8px]">
                    Out of Stock
                </div>
            </div>
            <div class="text-[18px] text-[#18282860]">
                <?php
                echo "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed malesuada nulla nec augue rhoncus, eget ullamcorper nulla ultrices. Fusce vulputate scelerisque est, ac venenatis nisi facilisis id. Vivamus vel massa eget velit sagittis blandit. Nullam condimentum ipsum nec purus finibus, ac mattis mauris malesuada. Fusce dignissim diam ut ligula tincidunt euismod. Proin ut mauris malesuada, placerat nulla sed, faucibus augue. Donec eget risus tellus. Phasellus euismod dui et lacus mollis ultricies. Mauris fringilla mauris libero, id pretium quam ultrices nec. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae<br><br>Allergy Information : Proin ut mauris malesuada, placerat nulla sed, faucibus augue.";
                ?>
            </div>
            <div class="flex flex-row flex-wrap justify-center gap-[16px] mt-[16px]">
                <button class="primary-filled-button w-[300px]" onclick="addToCart(id)">Add to Cart</button>
                <button class="primary-outlined-button w-[300px]" onclick="addToFavorites(id)">Add to Favorites</button>
            </div>

        </div>
    </div>

    <div class="lexend-medium text-[36px] mt-[32px]">Similar Products</div>
    <div class="flex flex-row overflow-auto gap-[32px] mt-[16px]">
        <?php
        if($productDetails){
            
        }
        vertical_product_card();
        vertical_product_card();
        vertical_product_card();
        vertical_product_card();
        vertical_product_card();
        vertical_product_card();
        vertical_product_card();
        vertical_product_card();
        ?>
    </div>

    <div class="lexend-medium text-[36px] mt-[32px]">Reviews</div>
    <div class="flex flex-column gap-[16px] mt-[16px]">
        <?php
        // if($reviews){
        //     foreach($reviews as $individualReview){

        //     }
        // }
        review_card(5);
        review_card(5);
        review_card(5);
        review_card(5);
        ?>
    </div>

    <?php include('../component/footer.php'); ?>
</body>
<script src="../component/header.js"></script>
<script src="../js_utils.js"></script>

</html>