<?php
namespace model;

include('../all_models.php');

$user = getUserDetails();
if ($user == null) {
    header('Location:../index.php');
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>
        <?php echo "Name"; ?>
    </title>
    <?php require('../common_links.php'); ?>
</head>

<body class="2xl:container mx-auto px-[16px]">
    <?php include('../component/header.php'); ?>

    <div class="flex flex-row flex-wrap gap-[32px] justify-center">
        <div class="flex flex-col w-[1100px]  bg-[#18282810] rounded-[8px] p-[16px] m-auto"
            style="background-image:url('../resources/img_profile.png');opacity:0.8;">
            <div class="text-[36px] lexend-medium">Welcome
                <?php echo ucFirst($user->firstname) ." " .ucFirst($user->lastname); ?>
            </div>
            <div class=" mt-[16px] text-[20px]">Age: <?php echo $user->age;?></div>
            <div class="text-[20px]">Gender: <?php echo ucFirst($user->gender);?></div>
            <div class="text-[20px]">Email: <?php echo $user->email;?></div>
            <div class="text-[20px]">Phone: <?php echo $user->phone;?></div>
            <div class="text-[20px] text-end">Joined Us On:</div>

        </div>

        <div
            class="flex flex-wrap justify-between items-center align-center  gap-[16px] flex-row 2xl:flex-col 2xl:w-[350px]">
            <?php
            if ($user->role != "customer") {
                echo '<a href="../interface/trader_interface.php"><button class="default-button">DASHBOARD</button></a>';
            }
            ?>
            <button class="default-button" onclick="redirectToFavourites()">FAVOURITES</button>
            <a href="../crud_pages/update_user_page.php"><button class="default-button">UPDATE</button></a>
            <?php
            if ($user->role == "customer") {
                echo '<button class="error-button" onclick="logOutClick()">LOG OUT</button>';
            }
            ?>
        </div>
    </div>

    <div class="lexend-medium text-[48px] my-[32px]">Recent Purchases</div>
    <?php

    $recentPurchasesQuery = "SELECT p.NAME, p.IMAGE, p.DESCRIPTION, p.PRICE
    FROM PRODUCT p
    JOIN ORDER_PRODUCT op ON op.PRODUCT_ID = p.PRODUCT_ID
    JOIN 'ORDER' o ON o.ORDER_ID = op.ORDER_ID
    JOIN CART c ON c.CART_ID = o.CART_ID
    JOIN 'USER' u ON u.USER_ID = c.USER_IDD
    WHERE o.status = 'delivered' AND u.USER_ID = $user->id;";

    horizontal_product_card_review(true);
    horizontal_product_card_review(true);
    horizontal_product_card_review(true);
    ?>


    <?php
    if ($user->role != "customer") {
        echo '<div class="justify-center flex ">
                <button class="error-button" onclick="logOutClick()">LOG OUT</button>
            </div>';
    }
    ?>

    <?php include('../component/footer.php'); ?>

</body>
<script src="../component/header.js"></script>
<script src="../js_utils.js"></script>

</html>