<?php

namespace model;

require_once('../all_models.php');

$SERVER_REFERER = "Location: {$_SERVER['HTTP_REFERER']}";
if (getLoggedInType() == "customer") {
    if (isDetailsValid()) {
        $description = $_POST['productReview'];
        $rating = $_POST['reviewRating'];
        $productId = $_GET['productId'];
        $userId = $_GET['userId'];
        $query = "INSERT INTO REVIEW (COMMENT, RATING, USER_ID, PRODUCT_ID) VALUES($description, $rating, $userId, $productId)";
        if (Dao::executeQuery($query)) {
            setsession(Constants::STATUS_SUCCESS, "Sucessfully sent your product review");
            removesession(Constants::CACHE_DESCRIPTION);
        }else{
            setsession(Constants::STATUS_ERROR, "Could not send your review.");
        }
    } 
} else {
    setsession(Constants::STATUS_ERROR, "Please be logged in as a customer to review a product.");
}

header($SERVER_REFERER);

function isDetailsValid()
{

    $isDescriptionValid = false;
    $isRatingValid = false;
    if (isset($_POST['productReview'])) {
        if (!empty(secure($_POST['productReview']))) {
            setsession(Constants::CACHE_DESCRIPTION, $_POST['productReview']);
            $isDescriptionValid = true;
        }
    }

    if (isset($_POST['reviewRating'])) {
        if ($_POST['reviewRating'] > 0) {
            $isRatingValid = true;
        }
    }

    if (!$isDescriptionValid) {
        setsession(Constants::DESCRIPTION_ERROR, "Please enter your review");
    }
    if (!$isRatingValid) {

    }

    return $isRatingValid and $isDescriptionValid;
}

?>