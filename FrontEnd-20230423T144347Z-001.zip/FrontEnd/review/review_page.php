<?php
namespace model;

include('../all_models.php');
$productId = $_GET['productId'];
$user = getUserDetails();
if ($user == null) {
    header("Location:../index.php");
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Review</title>
    <?php require('../common_links.php'); ?>
</head>

<body class="2xl:container mx-auto">
    <?php include('../component/header.php'); ?>
    <div class="lexend-medium text-[48px] my-[32px]">Review</div>
    <?php
    echo showSuccess(printSessionValue(Constants::STATUS_SUCCESS));
    echo showAlert(printSessionValue(Constants::STATUS_ERROR));


    horizontal_product_card_review(false);
    ?>
    <form action="<?php
    echo "review.php?userId=" . $user->id . "productId=" . $productId;
    ?>" method="POST">
        <div class="inputBx">
            <textarea name="productReview" placeholder="Enter your review here"
                value="<?php printSessionValue(Constants::CACHE_DESCRIPTION) ?>"></textarea>
            <div class="inputMessage">
                <?php printSessionValue(Constants::DESCRIPTION_ERROR) ?>
            </div>
        </div>

        <div class="flex flex-row flex-wrap align-center justify-end items-center gap-[32px]">
            <div class="flex flex-row gap-[4px] align-center items-center">
                <div class="rubik-medium text-[24px] mr-[8px] font-light">Rating</div>
                <div class="flex flex-row gap-[4px] align-center">
                    <i id="rating_1" class="bi bi-star"></i>
                    <i id="rating_2" class="bi bi-star"></i>
                    <i id="rating_3" class="bi bi-star"></i>
                    <i id="rating_4" class="bi bi-star"></i>
                    <i id="rating_5" class="bi bi-star"></i>
                </div>
            </div>
            <input type="hidden" value="0" name="reviewRating" id="reviewRating">
            <button class="primary-filled-button" onclick="this.form.submit()">Submit</button>
        </div>
    </form>
    <?php include('../component/footer.php'); ?>
</body>
<script src="../component/header.js"></script>
<script src="../js_utils.js"></script>
<script>
    const rating_1 = document.getElementById('rating_1');
    const rating_2 = document.getElementById('rating_2');
    const rating_3 = document.getElementById('rating_3');
    const rating_4 = document.getElementById('rating_4');
    const rating_5 = document.getElementById('rating_5');
    const reviewRating = document.getElementById('reviewRating');

    const ratingValue = [rating_1, rating_2, rating_3, rating_4, rating_5];
    rating_1.addEventListener('click', () => {
        onRatingClick(rating_1);
    })
    rating_2.addEventListener('click', () => {
        onRatingClick(rating_2);
    })
    rating_3.addEventListener('click', () => {
        onRatingClick(rating_3);
    })
    rating_4.addEventListener('click', () => {
        onRatingClick(rating_4);
    })
    rating_5.addEventListener('click', () => {
        onRatingClick(rating_5);
    })

    function onRatingClick(id) {
        //remove all filled star
        for (let i = 0; i < ratingValue.length; i++) {
            ratingValue[i].classList.remove('bi-star-fill')
            ratingValue[i].classList.add('bi-star')
        }

        for (let i = 0; i < ratingValue.length; i++) {
            ratingValue[i].classList.remove('bi-star');
            ratingValue[i].classList.add('bi-star-fill');
            if (id == ratingValue[i]) {
                reviewRating.value = i + 1;
                break;
            }
        }
    }

</script>

</html>