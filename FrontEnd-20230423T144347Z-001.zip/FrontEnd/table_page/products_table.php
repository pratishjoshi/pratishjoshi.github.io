<?php
namespace model;

require_once('../model/Constants.php');
include('../utils.php');
$count = 0;
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Products</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
    <?php include_once('../common_links.php'); ?>
</head>

<body class="2xl:container mx-auto px-[16px]">

    <?php
    include('../component/header.php');
    ?>

    <div class="flex flex-row flex-wrap justify-center items-center sm:justify-between sm:flex-column mb-[32px]">
        <div class="flex flex-row items-center gap-[16px]">
            <div class="lexend-regular text-[48px]">Products</div>
            <div class="px-[16px] py-[8px] text-[12px] text-[#18282860] bg-[#f5f7f6] rounded-[32px] max-h-[32px]">
                <?php echo $count; ?>
            </div>
        </div>

        <div class="flex flex-row flex-wrap justify-center items-center gap-[16px] md:gap-[48px]">
            <a href="../crud_pages/add_product_page.php">
                <button
                    class="primary-outlined-button w-[144px] h-[48px] rounded-[8px] text-[20px] lexend-regular capitalize">Add</button>
            </a>
            <form action="" method="POST">
                <div class="filter-filled">
                    <select name="sortFilter" onchange="">
                        <option value="" disabled selected>Sort</option>
                        <option value="">Id</option>
                        <option value="">Name</option>
                        <option value="">Price</option>
                        <option value="">Rating</option>
                    </select>
                </div>
            </form>
        </div>
    </div>

    <?php

    // Perform these on top
    $titles = array("Id" => "id", "Image" => "image", "Name" => "name", "Price" => "price", "Rating" => "rating");
    $values = array(
        array("id" => 1, "image" => "../resources/img_product.jpg", "name" => "Product Name", "price" => 10.00, "rating" => 5),
        array("id" => 1, "image" => "../resources/img_product.jpg", "name" => "Product Name", "price" => 10.00, "rating" => 5),
        array("id" => 1, "image" => "../resources/img_product.jpg", "name" => "Product Name", "price" => 10.00, "rating" => 5),
        array("id" => 1, "image" => "../resources/img_product.jpg", "name" => "Product Name", "price" => 10.00, "rating" => 5),
        array("id" => 1, "image" => "../resources/img_product.jpg", "name" => "Product Name", "price" => 10.00, "rating" => 5),
        array("id" => 1, "image" => "../resources/img_product.jpg", "name" => "Product Name", "price" => 10.00, "rating" => 5),
        array("id" => 1, "image" => "../resources/img_product.jpg", "name" => "Product Name", "price" => 10.00, "rating" => 5),
        array("id" => 1, "image" => "../resources/img_product.jpg", "name" => "Product Name", "price" => 10.00, "rating" => 5),
        array("id" => 1, "image" => "../resources/img_product.jpg", "name" => "Product Name", "price" => 10.00, "rating" => 5),
        array("id" => 1, "image" => "../resources/img_product.jpg", "name" => "Product Name", "price" => 10.00, "rating" => 5)
    );
    $count = count($values);

    product_table($titles, $values, "../crud_pages/update_product_page.php", "", true);
    ?>

    <?php include('../component/footer.php'); ?>
</body>
<script src="../component/header.js"></script>
<script src="../js_utils.js"></script>

</html>