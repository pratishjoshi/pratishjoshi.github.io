<?php
namespace model;

require_once('../model/Constants.php');
include('../utils.php');
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Shops</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
    <?php include_once('../common_links.php'); ?>
</head>

<body class="2xl:container mx-auto px-[16px]">

    <?php
    include('../component/header.php');
    ?>

    <div class="flex flex-row flex-wrap justify-center items-center sm:justify-between sm:flex-column mb-[32px]">
        <div class="flex flex-row items-center gap-[16px]">
            <div class="lexend-regular text-[48px]">Shops</div>
            <div class="px-[16px] py-[8px] text-[12px] text-[#18282860] bg-[#f5f7f6] rounded-[32px] max-h-[32px]">10
            </div>
        </div>

        <div class="flex flex-row flex-wrap justify-center items-center gap-[16px] md:gap-[48px]">
            <a href="../crud_pages/add_shop_page.php">
                <button
                    class="primary-outlined-button w-[144px] h-[48px] rounded-[8px] text-[20px] lexend-regular capitalize">Add</button>
            </a>
            <form action="" method="POST">
                <div class="filter-filled">
                    <select name="sortFilter" onchange="">
                        <option value="" disabled selected>Sort</option>
                        <option value="">Id</option>
                        <option value="">Name</option>
                    </select>
                </div>
            </form>
        </div>
    </div>

    <?php
    // Table here
    ?>

    <?php include('../component/footer.php'); ?>
</body>
<script src="../component/header.js"></script>
<script src="../js_utils.js"></script>

</html>