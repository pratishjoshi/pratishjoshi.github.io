<?php
namespace model;

require_once('../model/Constants.php');
include('../utils.php');
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Users</title>
    <?php include_once('../common_links.php'); ?>
</head>

<body class="2xl:container mx-auto px-[16px]">

    <?php
    include('../component/header.php');
    ?>

    <div class="flex flex-row flex-wrap justify-center items-center sm:justify-between sm:flex-column mb-[32px]">
        <div class="flex flex-row items-center gap-[16px]">
            <div class="lexend-regular text-[48px]">Users</div>
            <div class="px-[16px] py-[8px] text-[12px] text-[#18282860] bg-[#f5f7f6] rounded-[32px] max-h-[32px]">10
            </div>
        </div>

        <div class="flex flex-row flex-wrap justify-center items-center gap-[16px] md:gap-[48px]">
            <!-- <button
                class="primary-outlined-button w-[144px] h-[48px] rounded-[8px] text-[20px] lexend-regular capitalize">Add</button> -->

            <form action="" method="POST">
                <div class="filter-filled">
                    <select name="sortFilter" onchange="this.form.submit()">
                        <option value="" disabled selected>Sort</option>
                        <option value="id">Id</option>
                        <option value="name">Name</option>
                        <option value="number">Number</option>
                    </select>
                </div>
            </form>
        </div>
    </div>

    <?php
    // $query = "";
    // if(isset($_POST['sortFilter'])){
    //     //add condition in query 
    // }
    // $values = Dao::executeQueryForResult($query);

    $titles = array("Id" => "id", "Name" => "name", "Email" => "email", "Phone" => "phone");
    $values = array(
        array("id" => 1, "name" => "Sushant Neupane", "email" => "nsushant09@gmail.com", "phone" => "9823579122"),
        array("id" => 1, "name" => "Sushant Neupane", "email" => "nsushant09@gmail.com", "phone" => "9823579122"),
        array("id" => 1, "name" => "Sushant Neupane", "email" => "nsushant09@gmail.com", "phone" => "9823579122"),
        array("id" => 1, "name" => "Sushant Neupane", "email" => "nsushant09@gmail.com", "phone" => "9823579122"),
        array("id" => 1, "name" => "Sushant Neupane", "email" => "nsushant09@gmail.com", "phone" => "9823579122"),
        array("id" => 1, "name" => "Sushant Neupane", "email" => "nsushant09@gmail.com", "phone" => "9823579122"),
        array("id" => 1, "name" => "Sushant Neupane", "email" => "nsushant09@gmail.com", "phone" => "9823579122"),
        array("id" => 1, "name" => "Sushant Neupane", "email" => "nsushant09@gmail.com", "phone" => "9823579122"),
        array("id" => 1, "name" => "Sushant Neupane", "email" => "nsushant09@gmail.com", "phone" => "9823579122")
    );

    table($titles, $values, "../crud_pages/update_user_page.php","", true);
    ?>

    <?php include('../component/footer.php'); ?>
</body>
<script src="../component/header.js"></script>
<script src="../js_utils.js"></script>

</html>