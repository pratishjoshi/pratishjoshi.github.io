<?php
namespace model;

include('../allmodels.php');


if (isset($_POST['btnCreateAnAccountTr'])) {
    $SERVER_REFERER = "Location: {$_SERVER['HTTP_REFERER']}";
    $fullname = secure($_POST['fullnameTr']);
    $email = secure($_POST['emailTr']);
    $phone = secure($_POST['phoneTr']);
    $password = secure($_POST['passwordTr']);
    $age = secure($_POST['ageTr']);
    $gender = secure($_POST['genderTr']);
    $shopname = secure($_POST['shopNameTr']);
    $description = secure($_POST['descriptionTr']);

    if (isRegistrationDetailsValid($fullname, $email, $phone, $password, $age, $gender)) {
        $firstname = getFirstAndLastname(ucwords($fullname))['firstname'];
        $lastname = getFirstAndLastname(ucwords($fullname))['lastname'];
        $user = new User(-1, $firstname, $lastname, $phone, $email, $age, $gender, $password, "user");
        setsession(Constants::CACHE_USER_DETAILS, serialize($user));
        Mailer::sendVerificationEmail($email, 'trader_registration');

    }
    header($SERVER_REFERER);
}

if (isset($_POST['action']) && $_POST['action'] == "registration_auth") {
    if (isset($_POST['authKey']) && $_POST['authKey'] == $_COOKIE[Constants::ONE_TIME_PASSWORD]) {
        performRegistration();
    }
}

function performRegistration()
{
    // Send user details to admin
// Show sucessfull message / alert to user
    removemultiplesession(array(Constants::CACHE_USER_DETAILS, Constants::CACHE_GENDER));
    setsession(Constants::MAILER_STATUS_SUCCESS, "Your profile has been sent for Admin Verification<br>You will recieve a mail after your account is approved for trade.");
    header("Location:../login/login_page.php");
}

function isRegistrationDetailsValid($fullname, $email, $phone, $password, $age, $gender, $shopname, $description): bool
{
    $isvalidfullname = isValidFullName($fullname);
    $isvalidphone = isValidPhone($phone);
    $isvalidemail = isValidEmail($email);
    $isvalidpassword = isValidPassword($password);
    $isvalidshopname = isValidShopName($shopname);
    $isvaliddescription = isValidDescription($description);

    $isValid = $isvalidfullname && $isvalidphone && $isvalidpassword && $isvalidemail && $isvaliddescription && $isvalidshopname;
    if (!$isValid) {
        setsession(Constants::CACHE_FULL_NAME, $fullname);
        setsession(Constants::CACHE_EMAIL, $email);
        setsession(Constants::CACHE_PHONE, $phone);
        setsession(Constants::CACHE_AGE, $phone);
        setsession(Constants::CACHE_GENDER, $gender);
        setsession(Constants::CACHE_SHOP_NAME, $shopname);
        setsession(Constants::CACHE_DESCRIPTION, $description);

    }
    return $isValid;
}
?>