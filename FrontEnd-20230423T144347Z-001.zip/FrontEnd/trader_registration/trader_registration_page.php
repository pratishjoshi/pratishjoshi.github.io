<?php
namespace model;

include('../all_models.php');
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="../styles.css">
    <title>Trader Registration</title>
</head>

<body>
    <section>
        <div class="form-image">
            <img src="../resources/img_customer_register.jpg" alt="Display Image">
        </div>
        <div class="form-content">
            <div class="form">

                <div class="form-intro">
                    Welcome to <span style="cursor:pointer" onclick="redirectToIndex()">Freeman</span>,<br>Sell With Us.
                </div>
                <div class="form-introDesc">
                    <div>Want to shop with us? <a class="underline"
                            href="../customer_registration/customer_registration_page.php">Create an account</a></div>
                    <div>It takes less than a minute.</div>
                </div>
                <?php
                echo showSuccess(printSessionValue(Constants::MAILER_STATUS_SUCCESS));
                echo showAlert(printSessionValue(Constants::MAILER_STATUS_ERROR));
                ?>
                <form action="trader_registration.php" method="POST">

                    <div class="inputBx">
                        <span>Full Name</span>
                        <input type="text" name="fullnameTr"
                            value="<?php printSessionValue(Constants::CACHE_FULL_NAME) ?>">
                        <div class="inputMessage">
                            <?php printSessionValue(Constants::FULL_NAME_ERROR) ?>
                        </div>
                    </div>
                    <div class="inputBx">
                        <span>Phone Number</span>
                        <input type="number" name="phoneTr" value="<?php printSessionValue(Constants::CACHE_PHONE) ?>">
                        <div class="inputMessage">
                            <?php printSessionValue(Constants::PHONE_ERROR) ?>
                        </div>
                    </div>

                    <!-- Add Age and Gender here -->
                    <div class="flex flex-row justify-between mt-[-24px] mb-[-24px]">
                        <div class="w-[45%] inputBx">
                            <span>Age</span>
                            <input type="number" name="ageTr" value="<?php printSessionValue(Constants::CACHE_AGE) ?>">
                            <div class="inputMessage">
                                <?php printSessionValue(Constants::AGE_ERROR) ?>
                            </div>
                        </div>
                        <div class="w-[45%] inputBx">
                            <span>Gender</span>
                            <select name="genderTr">
                                <option value="male" <?php
                                if (getSessionValue(Constants::CACHE_GENDER) == "male") {
                                    echo "selected";
                                }
                                ?>>Male</option>
                                <option value="female" <?php
                                if (getSessionValue(Constants::CACHE_GENDER) == "female") {
                                    echo "selected";
                                }
                                ?>>Female</option>
                            </select>
                        </div>
                    </div>

                    <div class="inputBx">
                        <span>Email</span>
                        <input type="email" name="emailTr" value="<?php printSessionValue(Constants::CACHE_EMAIL) ?>">
                        <div class="inputMessage">
                            <?php printSessionValue(Constants::EMAIL_ERROR) ?>
                        </div>
                    </div>
                    <div class="inputBx">
                        <span>Shop Name</span>
                        <input type="text" name="shopNameTr"
                            value="<?php printSessionValue(Constants::CACHE_SHOP_NAME) ?>">
                        <div class="inputMessage">
                            <?php printSessionValue(Constants::SHOP_NAME_ERROR) ?>
                        </div>
                    </div>
                    <div class="inputBx">
                        <span>Description</span>
                        <textarea name="descriptionTr" placeholder="A breif description about your shop."
                            value="<?php printSessionValue(Constants::CACHE_DESCRIPTION) ?>"></textarea>
                        <div class="inputMessage">
                            <?php printSessionValue(Constants::DESCRIPTION_ERROR) ?>
                        </div>
                    </div>
                    <div class="inputBx">
                        <span>Password</span>
                        <input type="password" name="passwordTr">
                        <div class="inputMessage">
                            <?php printSessionValue(Constants::PASSWORD_ERROR) ?>
                        </div>
                    </div>

                    <div class="inputBx form-remDiv">
                        <div>Already have an account?&nbsp;
                            <a class="underline" href="../login/login_page.php">Login</a>
                        </div>
                    </div>
                    <div class="inputBx" style="margin-top:-32px">
                        <input type="submit" value="Create an account" name="btnCreateAnAccountCr">
                    </div>
                </form>
            </div>
        </div>
</body>
<script src="../js_utils.js"></script>

</html>
