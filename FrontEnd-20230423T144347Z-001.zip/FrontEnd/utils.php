<?php
use model\Constants;
use model\User;

session_start_by_check();

// Utility Methods
function secure(string $string): string
{
    return trim(
        strip_tags(
            htmlspecialchars(
                addslashes(
                    htmlentities(
                        htmlspecialchars($string)
                    )
                )
            )
        )
    );
}

function session_start_by_check()
{
    if (session_status() == PHP_SESSION_NONE) {
        session_start();
    }
}

function setsession(string $sessionConstant, string $sessionmessage): void
{
    $_SESSION[$sessionConstant] = $sessionmessage;
}

function removesession(string $sessionConstant): void
{
    if (isset($_SESSION[$sessionConstant])) {
        unset($_SESSION[$sessionConstant]);
    }
}
function removemultiplesession(array $sessions)
{
    foreach ($sessions as $session) {
        if (isset($_SESSION[$session])) {
            unset($_SESSION[$session]);
        }
    }
}

function removeCookie(string $cookieConstant)
{
    setcookie($cookieConstant, '', time() - 1, "/");
}

function removemultiplecookie(array $cookies)
{
    foreach ($cookies as $cookie) {
        setcookie($cookie, '', time() - 1, "/");
    }
}

function printSessionValue(string $sessionConstant)
{
    if (!empty($_SESSION[$sessionConstant])) {
        echo $_SESSION[$sessionConstant];
        unset($_SESSION[$sessionConstant]);
    }
}

function printCookieValue(string $cookieConstant)
{
    if (!empty($_COOKIE[$cookieConstant])) {
        echo $_COOKIE[$cookieConstant];
    }
}

function getSessionValue(string $sessionConstant)
{
    if (!empty($_SESSION[$sessionConstant])) {
        return $_SESSION[$sessionConstant];
    }
}

function getCookieValue(string $cookieConstant)
{
    if (!empty($_COOKIE[$cookieConstant])) {
        return $_COOKIE[$cookieConstant];
    }
}

function getLoggedInType(): ?string
{
    if (getCookieValue(Constants::LOGGED_IN_USER) == null) {
        return null;
    } else {
        $user = getCookieValue(Constants::LOGGED_IN_USER);
        return $user->role;

    }
}

function getUserDetails(): ?User
{
    if (getCookieValue(Constants::LOGGED_IN_USER) == null) {
        return null;
    } else {
        $user = getCookieValue(Constants::LOGGED_IN_USER);
        return $user;
    }
}

function createPostUrl(string $url, array $data): string
{
    $options = array(
        'http' => array(
            'method' => 'POST',
            'header' => 'Content-type: application/x-www-form-urlencoded',
            'content' => http_build_query($data),
        ),
    );
    $context = stream_context_create($options);
    $link = $url . '?' . http_build_query($data);
    return $link;
}

function getCurrentDate(): string
{
    return date('d/m/Y');
}

// Validation Methods

function validateEmpty($value, $sessionConstant, $errorMessage): bool
{
    if (empty($value)) {
        setsession($sessionConstant, $errorMessage);
        return false;
    }
    return true;
}
function isValidEmail(string $email): bool
{
    $regexPattern = '/^([a-z0-9\+_\-]+)(\.[a-z0-9\+_\-]+)*@([a-z0-9\-]+\.)+[a-z]{2,6}$/ix';
    if (empty($email)) {
        setsession(Constants::EMAIL_ERROR, "Please enter an email address");
        return false;
    } else if (!preg_match($regexPattern, $email)) {
        setsession(Constants::EMAIL_ERROR, "Invalid email format");
        return false;
    }
    return true;
}

function isValidImage($image)
{
    $imageType = $image['type'];
    if (empty($image['name'])) {
        setsession(Constants::PRODUCT_IMAGE_ERROR, "Please upload a product image");
        return false;
    } else if ($imageType != 'image/jpeg' and $imageType != 'image/jpg' and $imageType != 'image/png') {
        setsession(Constants::PRODUCT_IMAGE_ERROR, "Please select an image of valid type<br>i.e. jpeg, jpg, png");
        return false;
    }

    return true;
}

function isValidPassword(string $password): bool
{
    $regexPattern = '/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)[a-zA-Z\d!@#$%^&*()-_+=`~{}\[\]\\|:;"\'<>,.?\/]{8,}$/';
    if (empty($password)) {
        setsession(Constants::PASSWORD_ERROR, "Please enter a password");
        return false;
    } else if (!preg_match($regexPattern, $password)) {
        setsession(Constants::PASSWORD_ERROR, "Please confirm that your password contains<br>At least one uppercase letter, one lowercase letter and one number.");
        return false;
    }
    return true;
}

function isValidAge($age)
{
    if (empty($age)) {
        setsession(Constants::AGE_ERROR, "Please enter your age");
        return false;
    } else if (strlen($age) > 3) {
        setsession(Constants::AGE_ERROR, "Please enter a valid age");
        return false;
    }

    return true;
}

function isValidPhone($phoneNumber): bool
{
    $regexPattern = "#^(?:\+44\d{10}|0044\d{10}|0\d{10}|(\+977\d{8}|0\d{9}))$#";
    if (empty($phoneNumber)) {
        setsession(Constants::PHONE_ERROR, "Please enter a phone number");
        return false;
    }
    return true;
}

function isValidShopName($shopName): bool
{
    if (!empty($shopname)) {
        setsession(Constants::SHOP_NAME_ERROR, "Please enter your shopname");
        return false;
    }
    return true;
}
function isValidDescription($description): bool
{
    if (empty($description)) {
        setsession(Constants::DESCRIPTION_ERROR, "Please enter description");
        return false;
    }
    return true;
}

function isValidDataArray(array $array): bool
{
    return count($array) > 0;
}

function isValidFullName(string $fullName): bool
{
    $names = explode(" ", $fullName);
    if (empty($fullName)) {
        setsession(Constants::FULL_NAME_ERROR, "Please enter your full name.");
        return false;
    } else if (count($names) == 1) {
        setsession(Constants::FULL_NAME_ERROR, "Please enter your last name.");
        return false;
    } else if (count($names) > 2) {
        setsession(Constants::FULL_NAME_ERROR, "Please enter your first and last name only.");
        return false;
    }
    return true;
}

function getFirstAndLastname(string $fullname): array
{
    $names = explode(" ", $fullname);
    if (count($names) == 2) {
        return array(
            "firstname" => $names[0],
            "lastname" => $names[1]
        );
    }
    if (count($names) == 1) {
        return array(
            "firstname" => $names[0],
            "lastname" => ""
        );
    }
    if (count($names) == 0) {
        return array(
            "firstname" => "",
            "lastname" => ""
        );
    }
    return array(
        "firstname" => $names[0],
        "lastname" => $names[count($names)]
    );
}

// Reusable Components 

function showAlert($message)
{
    if (!empty($message)) {
        return '<div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative my-[16px]" role="alert">
            <span class="block sm:inline">' . $message . '</span>
        </div>';
    }
}

function showSuccess($message)
{
    if (!empty($message)) {
        return '<div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded relative my-[16px]" role="alert">
            <span class="block sm:inline">' . $message . '</span>
        </div>';
    }
}

function vertical_product_card()
{
    echo '<div class="vpc" onclick="productDetail(id)">
        <div class="vpc-img-container">
            <img src="../resources/img_login.jpg" alt="Wine" class="vpc-image">
            <div class="vpc-icon-container flex items-center justify-center cursor-pointer" onclick="addToFavourites(id)">
                <img src="../resources/ic_heart.svg" alt="Favorites Icon">
            </div>
        </div>
        <div class="flex flex-row justify-between items-center mt-[8px]">
            <div class="vpc-price">
                $200.48
            </div>
            <div class="text-[12px] mr-[8px] rubik-regular rounded-[2px] bg-[#d6275010] text-[#d62750] p-[4px]">
                Out of Stock
            </div>
        </div>
        <div class="vpc-title">
            Fine Wine
        </div>
        <div class="vpc-description">
            Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent interdum odio in massa sollicitudin, eu
            molestie risus faucibus.... a;lsdkf a;slkdjf a;slkdjf as;kdlfj as;dlkfj and this is for new line test
        </div>
        <div class="vpc-btn-atc flex flex-row items-center justify-center gap-[4px]" onclick="addToCart(id)">
            <img src="../resources/ic_cart_filled.svg" alt="Cart Icon">
            <div class="rubik-medium">ADD TO CART</div>
        </div>
    </div>';
}

function horizontal_product_card_favourites()
{
    ?>
    <div class="hpc" onclick="productDetail(id)">
        <div class="hpc-img-container">
            <img class="hpc-image" src="../resources/pngfind.com-wine-bottle-png-447037.png" alt="Product Image">
        </div>

        <div class="hpc-details-container">
            <div class="flex flex-row justify-between items-center">
                <div class="hpc-price">$200.48</div>
                <div class="text-[12px] mr-[8px] rubik-regular rounded-[2px] bg-[#d6275010] text-[#d62750] p-[4px]">
                    Out of Stock
                </div>
            </div>
            <div class="hpc-title">Fine Wine</div>
            <div class="hpc-description">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed malesuada nulla nec
                augue rhoncus, eget ullamcorper nulla ultrices. Fusce vulputate scelerisque est, ac venenatis nisi facilisis
                id. Vivamus vel massa eget velit sagittis blandit. Nullam condimentum ipsum nec purus finibus, ac mattis
                mauris malesuada. Fusce dignissim diam ut ligula tincidunt euismod. Proin ut mauris malesuada, placerat
                nulla sed, faucibus augue. Donec eget risus tellus. Phasellus euismod dui et lacus mollis ultricies. </div>
            <div class="hpc-buttons items-center flex-wrap">
                <button class="primary-filled-button" onclick="addToCart(id)">ADD TO CART</button>
                <button class="primary-outlined-button" onclick="removeFromFavorites(id)">REMOVE</button>
            </div>
        </div>
    </div>
    <?php
}
function horizontal_product_card_review($isReviewButtonVisible)
{
    ?>
    <div class="hpc" onclick="productDetail(id)">
        <div class="hpc-img-container">
            <img class="hpc-image" src="../resources/pngfind.com-wine-bottle-png-447037.png" alt="Product Image">
        </div>

        <div class="hpc-details-container">
            <div class="flex flex-row justify-between items-center">
                <div class="hpc-price">$200.48</div>
                <div class="text-[12px] mr-[8px] rubik-regular rounded-[2px] bg-[#d6275010] text-[#d62750] p-[4px]">
                    Out of Stock
                </div>
            </div>
            <div class="hpc-title">Fine Wine</div>
            <div class="hpc-description">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed malesuada nulla nec
                augue rhoncus, eget ullamcorper nulla ultrices. Fusce vulputate scelerisque est, ac venenatis nisi facilisis
                id. Vivamus vel massa eget velit sagittis blandit. Nullam condimentum ipsum nec purus finibus, ac mattis
                mauris malesuada. Fusce dignissim diam ut ligula tincidunt euismod. Proin ut mauris malesuada, placerat
                nulla sed, faucibus augue. Donec eget risus tellus. Phasellus euismod dui et lacus mollis ultricies. </div>
            <div class="hpc-review-buttons items-center flex-wrap">
                <div class="flex flex-row gap-[1.8vw]">
                    <div class="text-[18px] text-[#18282860] ">012-345-678-901-23</div>
                    <div>
                        <span class="text-[#18282860] text-[18px]">Quantity : </span>
                        <span class="text-[#18282860] text-[18px]">12</span>
                    </div>
                </div>
                <?php
                if ($isReviewButtonVisible) {
                    echo '<a href="#"><button class="primary-outlined-button">REVIEW</button></a>';
                }
                ?>
            </div>
        </div>
    </div>
    <?php
}

function horizontal_product_card_cart()
{
    ?>
    <div class="hpc" onclick="">
        <div class="hpc-img-container">
            <img class="hpc-image" src="../resources/pngfind.com-wine-bottle-png-447037.png" alt="Product Image">
        </div>

        <div class="hpc-details-container">
            <div class="flex flex-row justify-between items-center">
                <div class="hpc-price">$200.48</div>
                <div class="text-[12px] mr-[8px] rubik-regular rounded-[2px] bg-[#d6275010] text-[#d62750] p-[4px]">
                    Out of Stock
                </div>
            </div>
            <div class="hpc-title">Fine Wine</div>
            <div class="hpc-description">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed malesuada nulla nec
                augue rhoncus, eget ullamcorper nulla ultrices. Fusce vulputate scelerisque est, ac venenatis nisi facilisis
                id. Vivamus vel massa eget velit sagittis blandit. Nullam condimentum ipsum nec purus finibus, ac mattis
                mauris malesuada. Fusce dignissim diam ut ligula tincidunt euismod. Proin ut mauris malesuada, placerat
                nulla sed, faucibus augue. Donec eget risus tellus. Phasellus euismod dui et lacus mollis ultricies. </div>
            <!-- Pass id name in onclick functions  -->
            <div class="hpc-buttons items-center flex-wrap">
                <div class="quantity-selector flex flex-row items-center text-[18px] w-[96px]">
                    <img class="quantity-selector-icon quantity-increase basis-[10%]" src="../resources/ic_plus.svg"
                        alt="Increase" onclick="quantityIncrease('qc-id',20)">
                    <div class="quantity-count basis-[80%] justify-center text-center" id="qc-id">9</div>
                    <img class="quantity-selector-icon quantity-decrease basis-[10%]" src="../resources/ic_minus.svg"
                        alt="Decrease" onclick="quantityDecrease('qc-id',1)">
                </div>
                <button class="primary-outlined-button" onclick="removeFromCart(id)">REMOVE</button>
            </div>
        </div>
    </div>
    <?php
}

function review_card($reviewRating)
{
    ?>
    <div class="rc">
        <div class="rc-nad flex-wrap">
            <div class="text-[24px] rubik-regular">Sushant Neupane</div>
            <div class="text-[14px] text-[#18282860]">08/03/2023</div>
        </div>

        <div class="flex flex-row gap-x-[4px] items-center mt-[8px]">
            <?php
            for ($x = 1; $x <= $reviewRating; $x++) {
                echo display_stars();
            }
            ?>
        </div>

        <div class="mt-[16px] text-[18px] text-[#18282860]">
            Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed malesuada nulla nec augue rhoncus, eget ullamcorper
            nulla ultrices. Fusce vulputate scelerisque est, ac venenatis nisi facilisis id. Vivamus vel massa eget velit
            sagittis blandit. Nullam condimentum ipsum nec purus finibus, ac mattis mauris malesuada. Fusce dignissim diam
            ut ligula tincidunt euismod. Proin ut mauris malesuada, placerat nulla sed, faucibus augue. Donec eget risus
            tellus. Phasellus euismod dui et lacus mollis ultricies.
        </div>
    </div>
    <?php
}

function interface_card($imagepath, $title, $location)
{
    echo '
    <a href="' . $location . '">
    <div class="int-card-container">
        <img class="int-card-image" src="' . $imagepath . '" alt="' . $title . ' Image">
        <div class="int-card-title">' . $title . '</div>
    </div>
    </a>
    ';
}

function display_stars()
{
    return '<img src="../resources/ic_star_filled.svg" alt="Rating Star" class="w-[18px] h-[18px] text-[#182828]">';

}

/**
 * Pass Title along with key used in $values array. i.e. if Name should be display on top of table and $values[$innerarray['name']] = requiredValue
 * $title = array("Name" => "name")
 * $values will takes values of multiples user. i.e 
 * $value = array(
 *      array(...),
 *      array(...)
 * )
 * Here, each individual inner array contains data of items like user, order, shops, traders etc.
 * $updateDeleteLocation : send path to perform update and delete operations, set empty value if update and delete is not required
 * $isUpdateDeleteRequired : some tables might not require update and delete operations, set this to false if not required.
 */
function table(array $title, array $values, $updateLocation, $deleteLocation, $isUpdateDeleteRequired)
{
    $tableTitleName = array_keys($title);
    $itemValueKeys = array_values($title)
        ?>
    <div class="table-responsive">
        <table class="table">
            <thead>
                <tr>
                    <?php
                    foreach ($tableTitleName as $itemTitle) {
                        echo '<td class="text-2xl lexend-regular" scope="col">' . $itemTitle . '</td>';
                    }
                    ?>
                    <td class="text-2xl lexend-regular" scope="col">Update</td>
                    <td class="text-2xl lexend-regular" scope="col">Delete</td>
                </tr>
            </thead>
            <tbody>
                <?php
                foreach ($values as $itemValue) {
                    echo '<tr>';
                    echo ('<td scope="row" class="text-xl lexend-regular">' . $itemValue[$itemValueKeys[0]] . '</td>');
                    for ($x = 1; $x < count($itemValueKeys); $x++) {
                        echo '<td class="text-[#18282898] text-lg">' . $itemValue[$itemValueKeys[$x]] . '</td>';
                    }
                    if ($isUpdateDeleteRequired) {
                        echo ('<td class="text-[#182828] cursor-pointer"><a class="text-xl lexend-regular" href="' . $updateLocation . '?id=' . $itemValue[$itemValueKeys[0]] . '&action=update">Update</a></td>');
                        echo ('<td class="text-[#182828] cursor-pointer"><a class="text-xl lexend-regular" href="' . $deleteLocation . '?id=' . $itemValue[$itemValueKeys[0]] . '&action=delete">Delete</a></td>');
                    }
                    echo '</tr>';
                }
                ?>
            </tbody>
        </table>
    </div>
    <?php
}

/**
 * Check Table comments for hints.
 * Image for product is added so this table is made different to avoid any hassle.
 */
function product_table(array $title, array $values, $updateLocation, $deleteLocation, $isUpdateDeleteRequired)
{
    $tableTitleName = array_keys($title);
    $itemValueKeys = array_values($title)
        ?>
    <div class="table-responsive">
        <table class="table">
            <thead>
                <tr>
                    <?php
                    foreach ($tableTitleName as $itemTitle) {
                        echo '<td class="text-2xl lexend-regular" scope="col">' . $itemTitle . '</td>';
                    }
                    ?>
                    <td class="text-2xl lexend-regular" scope="col">Update</td>
                    <td class="text-2xl lexend-regular" scope="col">Delete</td>
                </tr>
            </thead>
            <tbody>
                <?php
                foreach ($values as $itemValue) {
                    echo '<tr>';
                    echo ('<td scope="row" class="text-xl lexend-regular">' . $itemValue[$itemValueKeys[0]] . '</td>');
                    for ($x = 1; $x < count($itemValueKeys); $x++) {
                        if ($itemValueKeys[$x] == "image") {
                            echo '<td><img class="w-[96px] h-[96px] object-cover" src="' . $itemValue[$itemValueKeys[$x]] . '" alt="' . $itemValue[$itemValueKeys[0]] . '"></td>';
                        } else {
                            echo '<td class="text-[#18282898] text-lg">' . $itemValue[$itemValueKeys[$x]] . '</td>';
                        }
                    }
                    if ($isUpdateDeleteRequired) {
                        echo ('<td class="text-[#182828] cursor-pointer"><a class="text-xl lexend-regular" href="' . $updateLocation . '?id=' . $itemValue[$itemValueKeys[0]] . '&action=update">Update</a></td>');
                        echo ('<td class="text-[#182828] cursor-pointer"><a class="text-xl lexend-regular" href="' . $deleteLocation . '?id=' . $itemValue[$itemValueKeys[0]] . '&action=delete">Delete</a></td>');
                    }
                    echo '</tr>';
                }
                ?>
            </tbody>
        </table>
    </div>
    <?php
}

function cart_table(array $title, array $values)
{
    $tableTitleName = array_keys($title);
    $itemValueKeys = array_values($title);
    ?>
    <div class="table-responsive">
        <table class="table">
            <thead>
                <tr>
                    <?php
                    foreach ($tableTitleName as $itemTitle) {
                        echo '<td class="lexend-regular text-2xl" scope="col">' . $itemTitle . '</td>';
                    }
                    ?>
                </tr>
            </thead>
            <tbody>
                <?php
                foreach ($values as $itemValue) {
                    echo '<tr>';
                    echo ('<td scope="row" class="lexend-regular text-xl">' . $itemValue[$itemValueKeys[0]] . '</td>');
                    for ($x = 1; $x < count($itemValueKeys); $x++) {
                        echo '<td class="text-[#18282898] text-lg ">' . $itemValue[$itemValueKeys[$x]] . '</td>';
                    }

                }

                ?>
                <tr>
                    <?php
                    for ($x = 2; $x < count($title); $x++) {
                        echo '<td></td>';
                    }
                    ?>
                    <td class="lexend-regular text-md"> Sub Total</td>
                    <td class=""></td>
                </tr>
                <tr>
                    <?php
                    for ($x = 2; $x < count($title); $x++) {
                        echo '<td></td>';
                    }
                    ?>
                    <td class=" lexend-regular text-md"> Discount</td>
                    <td class=""></td>
                </tr>
                <tr>
                    <?php
                    for ($x = 2; $x < count($title); $x++) {
                        echo '<td></td>';
                    }
                    ?>
                    <td class=" lexend-regular text-md"> Total</td>
                    <td class=""></td>
                </tr>

            </tbody>
        </table>
    </div>
    <?php
}
?>